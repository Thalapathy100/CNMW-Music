import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_de.dart';
import 'app_localizations_en.dart';
import 'app_localizations_es.dart';
import 'app_localizations_fr.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_ja.dart';
import 'app_localizations_ko.dart';
import 'app_localizations_pt.dart';
import 'app_localizations_tr.dart';
import 'app_localizations_zh.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
      : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('de'),
    Locale('en'),
    Locale('es'),
    Locale('fr'),
    Locale('hi'),
    Locale('ja'),
    Locale('ko'),
    Locale('pt'),
    Locale('tr'),
    Locale('zh')
  ];

  /// No description provided for @onboardingTitle.
  ///
  /// In en, this message translates to:
  /// **'Welcome to CNMW Music'**
  String get onboardingTitle;

  /// No description provided for @onboardingSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Let\'s set up your language and region.'**
  String get onboardingSubtitle;

  /// No description provided for @continueButton.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueButton;

  /// No description provided for @navHome.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get navHome;

  /// No description provided for @navLibrary.
  ///
  /// In en, this message translates to:
  /// **'Library'**
  String get navLibrary;

  /// No description provided for @navSearch.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get navSearch;

  /// No description provided for @navLocal.
  ///
  /// In en, this message translates to:
  /// **'Local'**
  String get navLocal;

  /// No description provided for @navOffline.
  ///
  /// In en, this message translates to:
  /// **'Offline'**
  String get navOffline;

  /// No description provided for @playerEnjoyingFrom.
  ///
  /// In en, this message translates to:
  /// **'Enjoying From'**
  String get playerEnjoyingFrom;

  /// No description provided for @playerPlayWithMix.
  ///
  /// In en, this message translates to:
  /// **'Auto-Mix Play'**
  String get playerPlayWithMix;

  /// No description provided for @playerPlayNext.
  ///
  /// In en, this message translates to:
  /// **'Play Next'**
  String get playerPlayNext;

  /// No description provided for @playerAddToQueue.
  ///
  /// In en, this message translates to:
  /// **'Add to Queue'**
  String get playerAddToQueue;

  /// No description provided for @playerAddToFavorites.
  ///
  /// In en, this message translates to:
  /// **'Add to Favorites'**
  String get playerAddToFavorites;

  /// No description provided for @playerNoLyricsFound.
  ///
  /// In en, this message translates to:
  /// **'No Lyrics Found'**
  String get playerNoLyricsFound;

  /// No description provided for @playerLyricsNoPlugin.
  ///
  /// In en, this message translates to:
  /// **'No lyrics provider configured. Go to Settings → Plugins to install one.'**
  String get playerLyricsNoPlugin;

  /// No description provided for @localMusicTitle.
  ///
  /// In en, this message translates to:
  /// **'Local'**
  String get localMusicTitle;

  /// No description provided for @localMusicGrantPermission.
  ///
  /// In en, this message translates to:
  /// **'Grant Permission'**
  String get localMusicGrantPermission;

  /// No description provided for @localMusicStorageAccessRequired.
  ///
  /// In en, this message translates to:
  /// **'Storage Access Required'**
  String get localMusicStorageAccessRequired;

  /// No description provided for @localMusicStorageAccessDesc.
  ///
  /// In en, this message translates to:
  /// **'Please grant permission to scan and play audio files stored on your device.'**
  String get localMusicStorageAccessDesc;

  /// No description provided for @localMusicAddFolder.
  ///
  /// In en, this message translates to:
  /// **'Add Music Folder'**
  String get localMusicAddFolder;

  /// No description provided for @localMusicScanNow.
  ///
  /// In en, this message translates to:
  /// **'Scan Now'**
  String get localMusicScanNow;

  /// No description provided for @localMusicScanFailed.
  ///
  /// In en, this message translates to:
  /// **'Scan failed: {message}'**
  String localMusicScanFailed(String message);

  /// No description provided for @localMusicScanning.
  ///
  /// In en, this message translates to:
  /// **'Scanning device for audio files...'**
  String get localMusicScanning;

  /// No description provided for @localMusicShuffle.
  ///
  /// In en, this message translates to:
  /// **'Shuffle'**
  String get localMusicShuffle;

  /// No description provided for @localMusicPlayAll.
  ///
  /// In en, this message translates to:
  /// **'Play All'**
  String get localMusicPlayAll;

  /// No description provided for @localMusicSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search local music...'**
  String get localMusicSearchHint;

  /// No description provided for @localMusicRescanDevice.
  ///
  /// In en, this message translates to:
  /// **'Rescan Device'**
  String get localMusicRescanDevice;

  /// No description provided for @buttonCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get buttonCancel;

  /// No description provided for @buttonDelete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get buttonDelete;

  /// No description provided for @buttonOk.
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get buttonOk;

  /// No description provided for @buttonUpdate.
  ///
  /// In en, this message translates to:
  /// **'Update'**
  String get buttonUpdate;

  /// No description provided for @buttonDownload.
  ///
  /// In en, this message translates to:
  /// **'Download'**
  String get buttonDownload;

  /// No description provided for @buttonLater.
  ///
  /// In en, this message translates to:
  /// **'Later'**
  String get buttonLater;

  /// No description provided for @buttonInfo.
  ///
  /// In en, this message translates to:
  /// **'Info'**
  String get buttonInfo;

  /// No description provided for @buttonMore.
  ///
  /// In en, this message translates to:
  /// **'More'**
  String get buttonMore;

  /// No description provided for @dialogDeleteTrack.
  ///
  /// In en, this message translates to:
  /// **'Delete Track'**
  String get dialogDeleteTrack;

  /// No description provided for @dialogDeleteTrackMessage.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete \"{title}\" from your device? This action cannot be undone.'**
  String dialogDeleteTrackMessage(String title);

  /// No description provided for @dialogDeleteTrackLinkedPlaylists.
  ///
  /// In en, this message translates to:
  /// **'This track will also be removed from:'**
  String get dialogDeleteTrackLinkedPlaylists;

  /// No description provided for @dialogDontAskAgain.
  ///
  /// In en, this message translates to:
  /// **'Don\'t ask me again'**
  String get dialogDontAskAgain;

  /// No description provided for @dialogUpdateAvailable.
  ///
  /// In en, this message translates to:
  /// **'Update Available'**
  String get dialogUpdateAvailable;

  /// No description provided for @dialogUpdateNow.
  ///
  /// In en, this message translates to:
  /// **'Update Now'**
  String get dialogUpdateNow;

  /// No description provided for @dialogDownloadPlaylist.
  ///
  /// In en, this message translates to:
  /// **'Download playlist'**
  String get dialogDownloadPlaylist;

  /// No description provided for @dialogDownloadPlaylistMessage.
  ///
  /// In en, this message translates to:
  /// **'Do you want to download {count} songs from \"{title}\"? This will add them to the download queue.'**
  String dialogDownloadPlaylistMessage(int count, String title);

  /// No description provided for @dialogDownloadAll.
  ///
  /// In en, this message translates to:
  /// **'Download All'**
  String get dialogDownloadAll;

  /// No description provided for @playlistEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit Playlist'**
  String get playlistEdit;

  /// No description provided for @playlistShareFile.
  ///
  /// In en, this message translates to:
  /// **'Share file'**
  String get playlistShareFile;

  /// No description provided for @playlistExportFile.
  ///
  /// In en, this message translates to:
  /// **'Export File'**
  String get playlistExportFile;

  /// No description provided for @playlistPlay.
  ///
  /// In en, this message translates to:
  /// **'Play'**
  String get playlistPlay;

  /// No description provided for @playlistAddToQueue.
  ///
  /// In en, this message translates to:
  /// **'Add Playlist to Queue'**
  String get playlistAddToQueue;

  /// No description provided for @playlistShare.
  ///
  /// In en, this message translates to:
  /// **'Share Playlist'**
  String get playlistShare;

  /// No description provided for @playlistDelete.
  ///
  /// In en, this message translates to:
  /// **'Delete Playlist'**
  String get playlistDelete;

  /// No description provided for @playlistEmptyState.
  ///
  /// In en, this message translates to:
  /// **'No songs yet'**
  String get playlistEmptyState;

  /// No description provided for @playlistAvailableOffline.
  ///
  /// In en, this message translates to:
  /// **'Available Offline'**
  String get playlistAvailableOffline;

  /// No description provided for @playlistShuffle.
  ///
  /// In en, this message translates to:
  /// **'Shuffle'**
  String get playlistShuffle;

  /// No description provided for @playlistNoMatchSearch.
  ///
  /// In en, this message translates to:
  /// **'No playlists match your search'**
  String get playlistNoMatchSearch;

  /// No description provided for @playlistCreateNew.
  ///
  /// In en, this message translates to:
  /// **'Create playlist'**
  String get playlistCreateNew;

  /// No description provided for @playlistCreateFirstOne.
  ///
  /// In en, this message translates to:
  /// **'No playlists yet. Create one to get started.'**
  String get playlistCreateFirstOne;

  /// No description provided for @addToPlaylistNoSongSelected.
  ///
  /// In en, this message translates to:
  /// **'No song selected'**
  String get addToPlaylistNoSongSelected;

  /// No description provided for @createPlaylistDialogBarrierLabel.
  ///
  /// In en, this message translates to:
  /// **'Create playlist dialog'**
  String get createPlaylistDialogBarrierLabel;

  /// No description provided for @createPlaylistDialogNameHint.
  ///
  /// In en, this message translates to:
  /// **'Summer Vibes'**
  String get createPlaylistDialogNameHint;

  /// No description provided for @createPlaylistDialogCreate.
  ///
  /// In en, this message translates to:
  /// **'Create'**
  String get createPlaylistDialogCreate;

  /// No description provided for @playlistSongCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 Song} other{{count} Songs}}'**
  String playlistSongCount(int count);

  /// No description provided for @playlistRemovedTrack.
  ///
  /// In en, this message translates to:
  /// **'{title} removed from {playlist}'**
  String playlistRemovedTrack(String title, String playlist);

  /// No description provided for @playlistFailedToLoad.
  ///
  /// In en, this message translates to:
  /// **'Failed to load playlist'**
  String get playlistFailedToLoad;

  /// No description provided for @settingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settingsTitle;

  /// No description provided for @settingsPlugins.
  ///
  /// In en, this message translates to:
  /// **'Plugins'**
  String get settingsPlugins;

  /// No description provided for @settingsPluginsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Install, load and manage plugins.'**
  String get settingsPluginsSubtitle;

  /// No description provided for @settingsDownloads.
  ///
  /// In en, this message translates to:
  /// **'Downloads'**
  String get settingsDownloads;

  /// No description provided for @settingsDownloadsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Download Path, Download Quality and more...'**
  String get settingsDownloadsSubtitle;

  /// No description provided for @settingsLocalTracks.
  ///
  /// In en, this message translates to:
  /// **'Local Tracks'**
  String get settingsLocalTracks;

  /// No description provided for @settingsLocalTracksSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Scan, manage folders and auto-scan settings.'**
  String get settingsLocalTracksSubtitle;

  /// No description provided for @settingsPlayer.
  ///
  /// In en, this message translates to:
  /// **'Player Settings'**
  String get settingsPlayer;

  /// No description provided for @settingsPlayerSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Stream quality, Auto Play, etc.'**
  String get settingsPlayerSubtitle;

  /// No description provided for @settingsPluginDefaults.
  ///
  /// In en, this message translates to:
  /// **'Plugin Defaults'**
  String get settingsPluginDefaults;

  /// No description provided for @settingsPluginDefaultsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Discover source, resolver priority.'**
  String get settingsPluginDefaultsSubtitle;

  /// No description provided for @settingsUIElements.
  ///
  /// In en, this message translates to:
  /// **'UI Elements & Services'**
  String get settingsUIElements;

  /// No description provided for @settingsUIElementsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Auto slide, UI tweaks etc.'**
  String get settingsUIElementsSubtitle;

  /// No description provided for @settingsLastFM.
  ///
  /// In en, this message translates to:
  /// **'Last.FM Settings'**
  String get settingsLastFM;

  /// No description provided for @settingsLastFMSubtitle.
  ///
  /// In en, this message translates to:
  /// **'API Key, Secret, and Scrobbling settings.'**
  String get settingsLastFMSubtitle;

  /// No description provided for @settingsStorage.
  ///
  /// In en, this message translates to:
  /// **'Storage'**
  String get settingsStorage;

  /// No description provided for @settingsStorageSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Backup, Cache, History, Restore and more...'**
  String get settingsStorageSubtitle;

  /// No description provided for @settingsLanguageCountry.
  ///
  /// In en, this message translates to:
  /// **'Language & Country'**
  String get settingsLanguageCountry;

  /// No description provided for @settingsLanguageCountrySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Select your language and country.'**
  String get settingsLanguageCountrySubtitle;

  /// No description provided for @settingsAbout.
  ///
  /// In en, this message translates to:
  /// **'About'**
  String get settingsAbout;

  /// No description provided for @settingsAboutSubtitle.
  ///
  /// In en, this message translates to:
  /// **'About the app, version, developer, etc.'**
  String get settingsAboutSubtitle;

  /// No description provided for @settingsScanning.
  ///
  /// In en, this message translates to:
  /// **'Scanning'**
  String get settingsScanning;

  /// No description provided for @settingsMusicFolders.
  ///
  /// In en, this message translates to:
  /// **'Music Folders'**
  String get settingsMusicFolders;

  /// No description provided for @settingsQuality.
  ///
  /// In en, this message translates to:
  /// **'Quality'**
  String get settingsQuality;

  /// No description provided for @settingsHistory.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get settingsHistory;

  /// No description provided for @settingsBackupRestore.
  ///
  /// In en, this message translates to:
  /// **'Backup & Restore'**
  String get settingsBackupRestore;

  /// No description provided for @settingsAutomatic.
  ///
  /// In en, this message translates to:
  /// **'Automatic'**
  String get settingsAutomatic;

  /// No description provided for @settingsDangerZone.
  ///
  /// In en, this message translates to:
  /// **'Danger Zone'**
  String get settingsDangerZone;

  /// No description provided for @settingsScrobbling.
  ///
  /// In en, this message translates to:
  /// **'Scrobbling'**
  String get settingsScrobbling;

  /// No description provided for @settingsAuthentication.
  ///
  /// In en, this message translates to:
  /// **'Authentication'**
  String get settingsAuthentication;

  /// No description provided for @settingsHomeScreen.
  ///
  /// In en, this message translates to:
  /// **'Home Screen'**
  String get settingsHomeScreen;

  /// No description provided for @settingsChartVisibility.
  ///
  /// In en, this message translates to:
  /// **'Chart Visibility'**
  String get settingsChartVisibility;

  /// No description provided for @dialogAddingToDownloadQueue.
  ///
  /// In en, this message translates to:
  /// **'Adding to download queue'**
  String get dialogAddingToDownloadQueue;

  /// No description provided for @emptyNoInternet.
  ///
  /// In en, this message translates to:
  /// **'No Internet Connection!'**
  String get emptyNoInternet;

  /// No description provided for @emptyNoContentPlugin.
  ///
  /// In en, this message translates to:
  /// **'No content plugin loaded. Load a Content Resolver in Plugin Manager.'**
  String get emptyNoContentPlugin;

  /// No description provided for @emptyRefreshingSource.
  ///
  /// In en, this message translates to:
  /// **'Refreshing Discover source... The previous source is no longer available.'**
  String get emptyRefreshingSource;

  /// No description provided for @emptyNoTracks.
  ///
  /// In en, this message translates to:
  /// **'No tracks available'**
  String get emptyNoTracks;

  /// No description provided for @emptyNoResults.
  ///
  /// In en, this message translates to:
  /// **'No matches found'**
  String get emptyNoResults;

  /// No description provided for @snackbarDeletedTrack.
  ///
  /// In en, this message translates to:
  /// **'Deleted \"{title}\"'**
  String snackbarDeletedTrack(String title);

  /// No description provided for @snackbarDeleteFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to delete \"{title}\"'**
  String snackbarDeleteFailed(String title);

  /// No description provided for @snackbarAddedToNextQueue.
  ///
  /// In en, this message translates to:
  /// **'Added to Next in Queue'**
  String get snackbarAddedToNextQueue;

  /// No description provided for @snackbarAddedToQueue.
  ///
  /// In en, this message translates to:
  /// **'Added to Queue'**
  String get snackbarAddedToQueue;

  /// No description provided for @snackbarAddedToLiked.
  ///
  /// In en, this message translates to:
  /// **'{title} added to favorites'**
  String snackbarAddedToLiked(String title);

  /// No description provided for @snackbarNowPlaying.
  ///
  /// In en, this message translates to:
  /// **'Playing {name}'**
  String snackbarNowPlaying(String name);

  /// No description provided for @snackbarPlaylistAddedToQueue.
  ///
  /// In en, this message translates to:
  /// **'Added {name} to Queue'**
  String snackbarPlaylistAddedToQueue(String name);

  /// No description provided for @snackbarPlaylistUpdated.
  ///
  /// In en, this message translates to:
  /// **'Playlist updated'**
  String get snackbarPlaylistUpdated;

  /// No description provided for @snackbarLinkCopied.
  ///
  /// In en, this message translates to:
  /// **'Link copied'**
  String get snackbarLinkCopied;

  /// No description provided for @snackbarCouldNotOpenLink.
  ///
  /// In en, this message translates to:
  /// **'Could not open link'**
  String get snackbarCouldNotOpenLink;

  /// No description provided for @snackbarSongsAddedToQueue.
  ///
  /// In en, this message translates to:
  /// **'Added {count} songs to download queue'**
  String snackbarSongsAddedToQueue(int count);

  /// No description provided for @searchHintExplore.
  ///
  /// In en, this message translates to:
  /// **'What do you want to listen to?'**
  String get searchHintExplore;

  /// No description provided for @searchHintLibrary.
  ///
  /// In en, this message translates to:
  /// **'Search library...'**
  String get searchHintLibrary;

  /// No description provided for @searchHintPlaylists.
  ///
  /// In en, this message translates to:
  /// **'Search playlists...'**
  String get searchHintPlaylists;

  /// No description provided for @searchStartTyping.
  ///
  /// In en, this message translates to:
  /// **'Start typing to search...'**
  String get searchStartTyping;

  /// No description provided for @searchNoSuggestions.
  ///
  /// In en, this message translates to:
  /// **'No Suggestions found!'**
  String get searchNoSuggestions;

  /// No description provided for @searchNoResults.
  ///
  /// In en, this message translates to:
  /// **'No results found!\nTry another keyword or source.'**
  String get searchNoResults;

  /// No description provided for @searchFailed.
  ///
  /// In en, this message translates to:
  /// **'Search failed!'**
  String get searchFailed;

  /// No description provided for @searchDiscover.
  ///
  /// In en, this message translates to:
  /// **'Discover new music'**
  String get searchDiscover;

  /// No description provided for @searchSources.
  ///
  /// In en, this message translates to:
  /// **'SOURCES'**
  String get searchSources;

  /// No description provided for @searchNoPlugins.
  ///
  /// In en, this message translates to:
  /// **'No plugins installed'**
  String get searchNoPlugins;

  /// No description provided for @searchTracks.
  ///
  /// In en, this message translates to:
  /// **'Tracks'**
  String get searchTracks;

  /// No description provided for @searchAlbums.
  ///
  /// In en, this message translates to:
  /// **'Albums'**
  String get searchAlbums;

  /// No description provided for @searchArtists.
  ///
  /// In en, this message translates to:
  /// **'Artists'**
  String get searchArtists;

  /// No description provided for @searchPlaylists.
  ///
  /// In en, this message translates to:
  /// **'Playlists'**
  String get searchPlaylists;

  /// No description provided for @exploreDiscover.
  ///
  /// In en, this message translates to:
  /// **'Discover'**
  String get exploreDiscover;

  /// No description provided for @exploreRecently.
  ///
  /// In en, this message translates to:
  /// **'Recently'**
  String get exploreRecently;

  /// No description provided for @exploreLastFmPicks.
  ///
  /// In en, this message translates to:
  /// **'Last.Fm Picks'**
  String get exploreLastFmPicks;

  /// No description provided for @exploreFailedToLoad.
  ///
  /// In en, this message translates to:
  /// **'Failed to load home sections.'**
  String get exploreFailedToLoad;

  /// No description provided for @libraryTitle.
  ///
  /// In en, this message translates to:
  /// **'Library'**
  String get libraryTitle;

  /// No description provided for @libraryEmptyState.
  ///
  /// In en, this message translates to:
  /// **'Your library is empty. Add songs and playlists to get started.'**
  String get libraryEmptyState;

  /// No description provided for @libraryIn.
  ///
  /// In en, this message translates to:
  /// **'in {playlistName}'**
  String libraryIn(String playlistName);

  /// No description provided for @menuAddToPlaylist.
  ///
  /// In en, this message translates to:
  /// **'Add to Playlist'**
  String get menuAddToPlaylist;

  /// No description provided for @menuSmartReplace.
  ///
  /// In en, this message translates to:
  /// **'Smart Replace'**
  String get menuSmartReplace;

  /// No description provided for @menuShare.
  ///
  /// In en, this message translates to:
  /// **'Share'**
  String get menuShare;

  /// No description provided for @menuAvailableOffline.
  ///
  /// In en, this message translates to:
  /// **'Available Offline'**
  String get menuAvailableOffline;

  /// No description provided for @menuDownload.
  ///
  /// In en, this message translates to:
  /// **'Download'**
  String get menuDownload;

  /// No description provided for @menuOpenOriginalLink.
  ///
  /// In en, this message translates to:
  /// **'Open original link'**
  String get menuOpenOriginalLink;

  /// No description provided for @menuDeleteTrack.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get menuDeleteTrack;

  /// No description provided for @tooltipRemoveFromLibrary.
  ///
  /// In en, this message translates to:
  /// **'Remove from Library'**
  String get tooltipRemoveFromLibrary;

  /// No description provided for @tooltipSaveToLibrary.
  ///
  /// In en, this message translates to:
  /// **'Save to Library'**
  String get tooltipSaveToLibrary;

  /// No description provided for @tooltipOpenOriginalLink.
  ///
  /// In en, this message translates to:
  /// **'Open Original Link'**
  String get tooltipOpenOriginalLink;

  /// No description provided for @tooltipAvailableOffline.
  ///
  /// In en, this message translates to:
  /// **'Available Offline'**
  String get tooltipAvailableOffline;

  /// No description provided for @tooltipMoreOptions.
  ///
  /// In en, this message translates to:
  /// **'More Options'**
  String get tooltipMoreOptions;

  /// No description provided for @appuiTitle.
  ///
  /// In en, this message translates to:
  /// **'UI & Services'**
  String get appuiTitle;

  /// No description provided for @appuiAutoSlideCharts.
  ///
  /// In en, this message translates to:
  /// **'Auto Slide Charts'**
  String get appuiAutoSlideCharts;

  /// No description provided for @appuiAutoSlideChartsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Slide charts automatically in home screen.'**
  String get appuiAutoSlideChartsSubtitle;

  /// No description provided for @appuiLastFmPicksSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Show suggestions from Last.FM. Login & restart required.'**
  String get appuiLastFmPicksSubtitle;

  /// No description provided for @appuiNoChartsAvailable.
  ///
  /// In en, this message translates to:
  /// **'No charts available. Load a chart provider plugin.'**
  String get appuiNoChartsAvailable;

  /// No description provided for @appuiLoginToLastFm.
  ///
  /// In en, this message translates to:
  /// **'Please login to Last.FM first.'**
  String get appuiLoginToLastFm;

  /// No description provided for @appuiShowInCarousel.
  ///
  /// In en, this message translates to:
  /// **'Show in home carousel.'**
  String get appuiShowInCarousel;

  /// No description provided for @countrySettingTitle.
  ///
  /// In en, this message translates to:
  /// **'Country & Language'**
  String get countrySettingTitle;

  /// No description provided for @countrySettingAutoDetect.
  ///
  /// In en, this message translates to:
  /// **'Auto Detect Country'**
  String get countrySettingAutoDetect;

  /// No description provided for @countrySettingAutoDetectSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Automatically detect your country when the app opens.'**
  String get countrySettingAutoDetectSubtitle;

  /// No description provided for @countrySettingCountryLabel.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get countrySettingCountryLabel;

  /// No description provided for @countrySettingLanguageLabel.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get countrySettingLanguageLabel;

  /// No description provided for @countrySettingSystemDefault.
  ///
  /// In en, this message translates to:
  /// **'System Default'**
  String get countrySettingSystemDefault;

  /// No description provided for @downloadSettingTitle.
  ///
  /// In en, this message translates to:
  /// **'Downloads'**
  String get downloadSettingTitle;

  /// No description provided for @downloadSettingQuality.
  ///
  /// In en, this message translates to:
  /// **'Download Quality'**
  String get downloadSettingQuality;

  /// No description provided for @downloadSettingQualitySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Universal audio quality preference for downloaded tracks.'**
  String get downloadSettingQualitySubtitle;

  /// No description provided for @downloadSettingFolder.
  ///
  /// In en, this message translates to:
  /// **'Download Folder'**
  String get downloadSettingFolder;

  /// No description provided for @downloadSettingResetFolder.
  ///
  /// In en, this message translates to:
  /// **'Reset Download Folder'**
  String get downloadSettingResetFolder;

  /// No description provided for @downloadSettingResetFolderSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Restore the default download path.'**
  String get downloadSettingResetFolderSubtitle;

  /// No description provided for @lastfmTitle.
  ///
  /// In en, this message translates to:
  /// **'Last.FM'**
  String get lastfmTitle;

  /// No description provided for @lastfmScrobbleTracks.
  ///
  /// In en, this message translates to:
  /// **'Scrobble Tracks'**
  String get lastfmScrobbleTracks;

  /// No description provided for @lastfmScrobbleTracksSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Send played tracks to your Last.FM profile.'**
  String get lastfmScrobbleTracksSubtitle;

  /// No description provided for @lastfmAuthFirst.
  ///
  /// In en, this message translates to:
  /// **'First Authenticate Last.FM API.'**
  String get lastfmAuthFirst;

  /// No description provided for @lastfmAuthenticatedAs.
  ///
  /// In en, this message translates to:
  /// **'Authenticated as'**
  String get lastfmAuthenticatedAs;

  /// No description provided for @lastfmAuthFailed.
  ///
  /// In en, this message translates to:
  /// **'Authentication failed:'**
  String get lastfmAuthFailed;

  /// No description provided for @lastfmNotAuthenticated.
  ///
  /// In en, this message translates to:
  /// **'Not authenticated'**
  String get lastfmNotAuthenticated;

  /// No description provided for @lastfmSteps.
  ///
  /// In en, this message translates to:
  /// **'Steps to authenticate:\n1. Create / open a Last.FM account at last.fm\n2. Generate an API Key at last.fm/api/account/create\n3. Enter your API Key & Secret below\n4. Tap \"Start Auth\" and approve in the browser\n5. Tap \"Get & Save Session Key\" to finish'**
  String get lastfmSteps;

  /// No description provided for @lastfmApiKey.
  ///
  /// In en, this message translates to:
  /// **'API Key'**
  String get lastfmApiKey;

  /// No description provided for @lastfmApiSecret.
  ///
  /// In en, this message translates to:
  /// **'API Secret'**
  String get lastfmApiSecret;

  /// No description provided for @lastfmStartAuth.
  ///
  /// In en, this message translates to:
  /// **'1. Start Auth'**
  String get lastfmStartAuth;

  /// No description provided for @lastfmGetSession.
  ///
  /// In en, this message translates to:
  /// **'2. Get & Save Session Key'**
  String get lastfmGetSession;

  /// No description provided for @lastfmRemoveKeys.
  ///
  /// In en, this message translates to:
  /// **'Remove Keys'**
  String get lastfmRemoveKeys;

  /// No description provided for @lastfmStartAuthFirst.
  ///
  /// In en, this message translates to:
  /// **'Start Auth first, then approve in browser.'**
  String get lastfmStartAuthFirst;

  /// No description provided for @localSettingTitle.
  ///
  /// In en, this message translates to:
  /// **'Local Tracks'**
  String get localSettingTitle;

  /// No description provided for @localSettingAutoScan.
  ///
  /// In en, this message translates to:
  /// **'Auto Scan on Startup'**
  String get localSettingAutoScan;

  /// No description provided for @localSettingAutoScanSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Automatically scan for new local tracks when the app starts.'**
  String get localSettingAutoScanSubtitle;

  /// No description provided for @localSettingLastScan.
  ///
  /// In en, this message translates to:
  /// **'Last Scan'**
  String get localSettingLastScan;

  /// No description provided for @localSettingNeverScanned.
  ///
  /// In en, this message translates to:
  /// **'Never'**
  String get localSettingNeverScanned;

  /// No description provided for @localSettingScanInProgress.
  ///
  /// In en, this message translates to:
  /// **'Scanning in progress…'**
  String get localSettingScanInProgress;

  /// No description provided for @localSettingScanNowSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Manually trigger a full library scan.'**
  String get localSettingScanNowSubtitle;

  /// No description provided for @localSettingNoFolders.
  ///
  /// In en, this message translates to:
  /// **'No folders added. Add a folder to start scanning.'**
  String get localSettingNoFolders;

  /// No description provided for @localSettingAddFolder.
  ///
  /// In en, this message translates to:
  /// **'Add Folder'**
  String get localSettingAddFolder;

  /// No description provided for @playerSettingTitle.
  ///
  /// In en, this message translates to:
  /// **'Player Settings'**
  String get playerSettingTitle;

  /// No description provided for @playerSettingStreamingHeader.
  ///
  /// In en, this message translates to:
  /// **'Streaming'**
  String get playerSettingStreamingHeader;

  /// No description provided for @playerSettingStreamQuality.
  ///
  /// In en, this message translates to:
  /// **'Streaming Quality'**
  String get playerSettingStreamQuality;

  /// No description provided for @playerSettingStreamQualitySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Global audio bitrate for online playback.'**
  String get playerSettingStreamQualitySubtitle;

  /// No description provided for @playerSettingQualityLow.
  ///
  /// In en, this message translates to:
  /// **'Low'**
  String get playerSettingQualityLow;

  /// No description provided for @playerSettingQualityMedium.
  ///
  /// In en, this message translates to:
  /// **'Medium'**
  String get playerSettingQualityMedium;

  /// No description provided for @playerSettingQualityHigh.
  ///
  /// In en, this message translates to:
  /// **'High'**
  String get playerSettingQualityHigh;

  /// No description provided for @playerSettingPlaybackHeader.
  ///
  /// In en, this message translates to:
  /// **'Playback'**
  String get playerSettingPlaybackHeader;

  /// No description provided for @playerSettingAutoPlay.
  ///
  /// In en, this message translates to:
  /// **'Auto Play'**
  String get playerSettingAutoPlay;

  /// No description provided for @playerSettingAutoPlaySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enqueue similar songs when the queue ends.'**
  String get playerSettingAutoPlaySubtitle;

  /// No description provided for @playerSettingAutoFallback.
  ///
  /// In en, this message translates to:
  /// **'Auto Fallback Playback'**
  String get playerSettingAutoFallback;

  /// No description provided for @playerSettingAutoFallbackSubtitle.
  ///
  /// In en, this message translates to:
  /// **'If a plugin is missing or returns no streams, try a compatible resolver for playback only.'**
  String get playerSettingAutoFallbackSubtitle;

  /// No description provided for @playerSettingCrossfade.
  ///
  /// In en, this message translates to:
  /// **'Crossfade'**
  String get playerSettingCrossfade;

  /// No description provided for @playerSettingCrossfadeOff.
  ///
  /// In en, this message translates to:
  /// **'Off'**
  String get playerSettingCrossfadeOff;

  /// No description provided for @playerSettingCrossfadeInstant.
  ///
  /// In en, this message translates to:
  /// **'Tracks switch instantly'**
  String get playerSettingCrossfadeInstant;

  /// No description provided for @playerSettingCrossfadeBlend.
  ///
  /// In en, this message translates to:
  /// **'{seconds}s blend between tracks'**
  String playerSettingCrossfadeBlend(int seconds);

  /// No description provided for @playerSettingEqualizer.
  ///
  /// In en, this message translates to:
  /// **'Equalizer'**
  String get playerSettingEqualizer;

  /// No description provided for @playerSettingEqualizerActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get playerSettingEqualizerActive;

  /// No description provided for @playerSettingEqualizerActivePreset.
  ///
  /// In en, this message translates to:
  /// **'Enabled — {preset} preset'**
  String playerSettingEqualizerActivePreset(String preset);

  /// No description provided for @playerSettingEqualizerSubtitle.
  ///
  /// In en, this message translates to:
  /// **'10-band parametric EQ via FFmpeg.'**
  String get playerSettingEqualizerSubtitle;

  /// No description provided for @pluginDefaultsTitle.
  ///
  /// In en, this message translates to:
  /// **'Plugin Defaults'**
  String get pluginDefaultsTitle;

  /// No description provided for @pluginDefaultsDiscoverHeader.
  ///
  /// In en, this message translates to:
  /// **'Discover Source'**
  String get pluginDefaultsDiscoverHeader;

  /// No description provided for @pluginDefaultsNoResolver.
  ///
  /// In en, this message translates to:
  /// **'No content resolver loaded. Load a plugin to choose a Discover source.'**
  String get pluginDefaultsNoResolver;

  /// No description provided for @pluginDefaultsAutomaticSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Use the first available content resolver.'**
  String get pluginDefaultsAutomaticSubtitle;

  /// No description provided for @pluginDefaultsPriorityHeader.
  ///
  /// In en, this message translates to:
  /// **'Resolver Priority'**
  String get pluginDefaultsPriorityHeader;

  /// No description provided for @pluginDefaultsNoPriority.
  ///
  /// In en, this message translates to:
  /// **'No content resolvers loaded. Priority ordering will appear here once plugins are loaded.'**
  String get pluginDefaultsNoPriority;

  /// No description provided for @pluginDefaultsPriorityDesc.
  ///
  /// In en, this message translates to:
  /// **'Drag to reorder. Higher priority resolvers are tried first when resolving chart items or imported tracks to playable tracks.'**
  String get pluginDefaultsPriorityDesc;

  /// No description provided for @pluginDefaultsLyricsHeader.
  ///
  /// In en, this message translates to:
  /// **'Lyrics Priority'**
  String get pluginDefaultsLyricsHeader;

  /// No description provided for @pluginDefaultsLyricsNone.
  ///
  /// In en, this message translates to:
  /// **'No lyrics providers loaded.'**
  String get pluginDefaultsLyricsNone;

  /// No description provided for @pluginDefaultsLyricsDesc.
  ///
  /// In en, this message translates to:
  /// **'Drag to reorder lyrics providers. The first provider is tried first.'**
  String get pluginDefaultsLyricsDesc;

  /// No description provided for @pluginDefaultsSuggestionsHeader.
  ///
  /// In en, this message translates to:
  /// **'Search Suggestions'**
  String get pluginDefaultsSuggestionsHeader;

  /// No description provided for @pluginDefaultsSuggestionsNone.
  ///
  /// In en, this message translates to:
  /// **'No suggestion providers loaded.'**
  String get pluginDefaultsSuggestionsNone;

  /// No description provided for @pluginDefaultsSuggestionsHistoryOnlyTitle.
  ///
  /// In en, this message translates to:
  /// **'None'**
  String get pluginDefaultsSuggestionsHistoryOnlyTitle;

  /// No description provided for @pluginDefaultsSuggestionsHistoryOnlySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Use search history only.'**
  String get pluginDefaultsSuggestionsHistoryOnlySubtitle;

  /// No description provided for @storageSettingTitle.
  ///
  /// In en, this message translates to:
  /// **'Storage'**
  String get storageSettingTitle;

  /// No description provided for @storageClearHistoryEvery.
  ///
  /// In en, this message translates to:
  /// **'Clear History In Every'**
  String get storageClearHistoryEvery;

  /// No description provided for @storageClearHistorySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Clear listening history after the chosen period.'**
  String get storageClearHistorySubtitle;

  /// No description provided for @storageDays.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 Day} other{{count} Days}}'**
  String storageDays(int count);

  /// No description provided for @storageBackupCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Backup created at {path}'**
  String storageBackupCreatedAt(String path);

  /// No description provided for @storageBackupShareFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to share backup: {error}'**
  String storageBackupShareFailed(String error);

  /// No description provided for @storageRestoreBackup.
  ///
  /// In en, this message translates to:
  /// **'Restore Backup'**
  String get storageRestoreBackup;

  /// No description provided for @storageRestoreBackupSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Restore your settings and data from a backup file.'**
  String get storageRestoreBackupSubtitle;

  /// No description provided for @storageAutoBackup.
  ///
  /// In en, this message translates to:
  /// **'Auto Backup'**
  String get storageAutoBackup;

  /// No description provided for @storageAutoLyrics.
  ///
  /// In en, this message translates to:
  /// **'Auto Save Lyrics'**
  String get storageAutoLyrics;

  /// No description provided for @storageAutoLyricsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Save lyrics automatically when a song plays.'**
  String get storageAutoLyricsSubtitle;

  /// No description provided for @storageResetApp.
  ///
  /// In en, this message translates to:
  /// **'Reset CNMW Music App'**
  String get storageResetApp;

  /// No description provided for @storageResetConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Confirm Reset'**
  String get storageResetConfirmTitle;

  /// No description provided for @storageResetButton.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get storageResetButton;

  /// No description provided for @storageRestoreOptionsTitle.
  ///
  /// In en, this message translates to:
  /// **'Restore Options'**
  String get storageRestoreOptionsTitle;

  /// No description provided for @storageRestoreContinue.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get storageRestoreContinue;

  /// No description provided for @storageRestoreConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Confirm Restore'**
  String get storageRestoreConfirmTitle;

  /// No description provided for @storageRestoreYes.
  ///
  /// In en, this message translates to:
  /// **'Yes, restore'**
  String get storageRestoreYes;

  /// No description provided for @storageRestoring.
  ///
  /// In en, this message translates to:
  /// **'Restoring selected data…\nPlease wait until the operation completes.'**
  String get storageRestoring;

  /// No description provided for @storageRestoreFailedTitle.
  ///
  /// In en, this message translates to:
  /// **'Restore Failed'**
  String get storageRestoreFailedTitle;

  /// No description provided for @updateSettingTitle.
  ///
  /// In en, this message translates to:
  /// **'Updates'**
  String get updateSettingTitle;

  /// No description provided for @updateCheckForUpdates.
  ///
  /// In en, this message translates to:
  /// **'Check for Updates'**
  String get updateCheckForUpdates;

  /// No description provided for @updateCheckSubtitle.
  ///
  /// In en, this message translates to:
  /// **'See if a newer version of CNMW Music is available.'**
  String get updateCheckSubtitle;

  /// No description provided for @updateAutoNotify.
  ///
  /// In en, this message translates to:
  /// **'Auto Update Notify'**
  String get updateAutoNotify;

  /// No description provided for @updateAutoNotifySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Get notified when new updates are available on app start.'**
  String get updateAutoNotifySubtitle;

  /// No description provided for @updateCheckTitle.
  ///
  /// In en, this message translates to:
  /// **'Check for Updates'**
  String get updateCheckTitle;

  /// No description provided for @updateUpToDate.
  ///
  /// In en, this message translates to:
  /// **'CNMW Music is up to date'**
  String get updateUpToDate;

  /// No description provided for @updateViewPreRelease.
  ///
  /// In en, this message translates to:
  /// **'View Latest Pre-Release'**
  String get updateViewPreRelease;

  /// No description provided for @updateCurrentVersion.
  ///
  /// In en, this message translates to:
  /// **'Current Version: {curr} + {build}'**
  String updateCurrentVersion(String curr, String build);

  /// No description provided for @updateNewVersionAvailable.
  ///
  /// In en, this message translates to:
  /// **'A new version of CNMW Music is available'**
  String get updateNewVersionAvailable;

  /// No description provided for @updateVersion.
  ///
  /// In en, this message translates to:
  /// **'Version: {ver}+{build}'**
  String updateVersion(String ver, String build);

  /// No description provided for @updateDownloadNow.
  ///
  /// In en, this message translates to:
  /// **'Download Now'**
  String get updateDownloadNow;

  /// No description provided for @updateChecking.
  ///
  /// In en, this message translates to:
  /// **'Checking for updates…'**
  String get updateChecking;

  /// No description provided for @timerTitle.
  ///
  /// In en, this message translates to:
  /// **'Sleep Timer'**
  String get timerTitle;

  /// No description provided for @timerInterludeMessage.
  ///
  /// In en, this message translates to:
  /// **'Playback will stop in…'**
  String get timerInterludeMessage;

  /// No description provided for @timerHours.
  ///
  /// In en, this message translates to:
  /// **'Hours'**
  String get timerHours;

  /// No description provided for @timerMinutes.
  ///
  /// In en, this message translates to:
  /// **'Minutes'**
  String get timerMinutes;

  /// No description provided for @timerSeconds.
  ///
  /// In en, this message translates to:
  /// **'Seconds'**
  String get timerSeconds;

  /// No description provided for @timerStop.
  ///
  /// In en, this message translates to:
  /// **'Stop Timer'**
  String get timerStop;

  /// No description provided for @timerFinishedMessage.
  ///
  /// In en, this message translates to:
  /// **'The sleep timer stopped playback.'**
  String get timerFinishedMessage;

  /// No description provided for @timerGotIt.
  ///
  /// In en, this message translates to:
  /// **'Got it!'**
  String get timerGotIt;

  /// No description provided for @timerSetTimeError.
  ///
  /// In en, this message translates to:
  /// **'Please set a time'**
  String get timerSetTimeError;

  /// No description provided for @timerStart.
  ///
  /// In en, this message translates to:
  /// **'Start Timer'**
  String get timerStart;

  /// No description provided for @notificationsTitle.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notificationsTitle;

  /// No description provided for @recentsTitle.
  ///
  /// In en, this message translates to:
  /// **'History'**
  String get recentsTitle;

  /// No description provided for @playlistByCreator.
  ///
  /// In en, this message translates to:
  /// **'by {creator}'**
  String playlistByCreator(String creator);

  /// No description provided for @playlistYou.
  ///
  /// In en, this message translates to:
  /// **'You'**
  String get playlistYou;

  /// No description provided for @pluginManagerTitle.
  ///
  /// In en, this message translates to:
  /// **'Plugins'**
  String get pluginManagerTitle;

  /// No description provided for @pluginManagerEmpty.
  ///
  /// In en, this message translates to:
  /// **'No plugins installed.\nTap + to add a .bex file.'**
  String get pluginManagerEmpty;

  /// No description provided for @pluginManagerFilterAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get pluginManagerFilterAll;

  /// No description provided for @pluginManagerFilterContent.
  ///
  /// In en, this message translates to:
  /// **'Content Resolvers'**
  String get pluginManagerFilterContent;

  /// No description provided for @pluginManagerFilterCharts.
  ///
  /// In en, this message translates to:
  /// **'Chart Providers'**
  String get pluginManagerFilterCharts;

  /// No description provided for @pluginManagerFilterLyrics.
  ///
  /// In en, this message translates to:
  /// **'Lyrics Providers'**
  String get pluginManagerFilterLyrics;

  /// No description provided for @pluginManagerFilterSuggestions.
  ///
  /// In en, this message translates to:
  /// **'Suggestion Providers'**
  String get pluginManagerFilterSuggestions;

  /// No description provided for @pluginManagerFilterImporters.
  ///
  /// In en, this message translates to:
  /// **'Content Importers'**
  String get pluginManagerFilterImporters;

  /// No description provided for @pluginManagerTooltipRefresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get pluginManagerTooltipRefresh;

  /// No description provided for @pluginManagerTooltipInstall.
  ///
  /// In en, this message translates to:
  /// **'Install Plugin'**
  String get pluginManagerTooltipInstall;

  /// No description provided for @pluginManagerNoMatch.
  ///
  /// In en, this message translates to:
  /// **'No plugins match this filter'**
  String get pluginManagerNoMatch;

  /// No description provided for @pluginManagerPickFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to pick file: {error}'**
  String pluginManagerPickFailed(String error);

  /// No description provided for @pluginManagerInstalling.
  ///
  /// In en, this message translates to:
  /// **'Installing plugin...'**
  String get pluginManagerInstalling;

  /// No description provided for @pluginManagerTypeContentResolver.
  ///
  /// In en, this message translates to:
  /// **'Content Resolver'**
  String get pluginManagerTypeContentResolver;

  /// No description provided for @pluginManagerTypeChartProvider.
  ///
  /// In en, this message translates to:
  /// **'Chart Provider'**
  String get pluginManagerTypeChartProvider;

  /// No description provided for @pluginManagerTypeLyricsProvider.
  ///
  /// In en, this message translates to:
  /// **'Lyrics Provider'**
  String get pluginManagerTypeLyricsProvider;

  /// No description provided for @pluginManagerTypeSuggestionProvider.
  ///
  /// In en, this message translates to:
  /// **'Search Suggestions'**
  String get pluginManagerTypeSuggestionProvider;

  /// No description provided for @pluginManagerTypeContentImporter.
  ///
  /// In en, this message translates to:
  /// **'Content Importer'**
  String get pluginManagerTypeContentImporter;

  /// No description provided for @pluginManagerDeleteTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete Plugin?'**
  String get pluginManagerDeleteTitle;

  /// No description provided for @pluginManagerDeleteMessage.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete \"{name}\"? This will permanently remove its files.'**
  String pluginManagerDeleteMessage(String name);

  /// No description provided for @pluginManagerDeleteAction.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get pluginManagerDeleteAction;

  /// No description provided for @pluginManagerCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get pluginManagerCancel;

  /// No description provided for @pluginManagerEnablePlugin.
  ///
  /// In en, this message translates to:
  /// **'Enable Plugin'**
  String get pluginManagerEnablePlugin;

  /// No description provided for @pluginManagerUnloadPlugin.
  ///
  /// In en, this message translates to:
  /// **'Unload Plugin'**
  String get pluginManagerUnloadPlugin;

  /// No description provided for @pluginManagerDeleting.
  ///
  /// In en, this message translates to:
  /// **'Deleting...'**
  String get pluginManagerDeleting;

  /// No description provided for @pluginManagerApiKeysTitle.
  ///
  /// In en, this message translates to:
  /// **'API Keys'**
  String get pluginManagerApiKeysTitle;

  /// No description provided for @pluginManagerApiKeysSaved.
  ///
  /// In en, this message translates to:
  /// **'API keys saved'**
  String get pluginManagerApiKeysSaved;

  /// No description provided for @pluginManagerSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get pluginManagerSave;

  /// No description provided for @pluginManagerDetailVersion.
  ///
  /// In en, this message translates to:
  /// **'Version'**
  String get pluginManagerDetailVersion;

  /// No description provided for @pluginManagerDetailType.
  ///
  /// In en, this message translates to:
  /// **'Type'**
  String get pluginManagerDetailType;

  /// No description provided for @pluginManagerDetailPublisher.
  ///
  /// In en, this message translates to:
  /// **'Publisher'**
  String get pluginManagerDetailPublisher;

  /// No description provided for @pluginManagerDetailLastUpdated.
  ///
  /// In en, this message translates to:
  /// **'Last Updated'**
  String get pluginManagerDetailLastUpdated;

  /// No description provided for @pluginManagerDetailCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get pluginManagerDetailCreated;

  /// No description provided for @pluginManagerDetailHomepage.
  ///
  /// In en, this message translates to:
  /// **'Homepage'**
  String get pluginManagerDetailHomepage;

  /// No description provided for @pluginManagerDeleteStorageTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete Plugin Data?'**
  String get pluginManagerDeleteStorageTitle;

  /// No description provided for @pluginManagerDeleteStorageMessage.
  ///
  /// In en, this message translates to:
  /// **'Also remove saved API keys and settings for \"{name}\"?'**
  String pluginManagerDeleteStorageMessage(String name);

  /// No description provided for @pluginManagerDeleteStorageKeep.
  ///
  /// In en, this message translates to:
  /// **'Keep Data'**
  String get pluginManagerDeleteStorageKeep;

  /// No description provided for @pluginManagerDeleteStorageRemove.
  ///
  /// In en, this message translates to:
  /// **'Remove Data'**
  String get pluginManagerDeleteStorageRemove;

  /// No description provided for @segmentsSheetTitle.
  ///
  /// In en, this message translates to:
  /// **'Segments'**
  String get segmentsSheetTitle;

  /// No description provided for @segmentsSheetEmpty.
  ///
  /// In en, this message translates to:
  /// **'No segments available'**
  String get segmentsSheetEmpty;

  /// No description provided for @segmentsSheetUntitled.
  ///
  /// In en, this message translates to:
  /// **'Untitled Segment'**
  String get segmentsSheetUntitled;

  /// No description provided for @smartReplaceTitle.
  ///
  /// In en, this message translates to:
  /// **'Smart Replace'**
  String get smartReplaceTitle;

  /// No description provided for @smartReplaceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose a playable replacement for \"{title}\" and update saved playlist references.'**
  String smartReplaceSubtitle(String title);

  /// No description provided for @smartReplaceClose.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get smartReplaceClose;

  /// No description provided for @smartReplaceNoMatch.
  ///
  /// In en, this message translates to:
  /// **'No replacement found'**
  String get smartReplaceNoMatch;

  /// No description provided for @smartReplaceNoMatchSubtitle.
  ///
  /// In en, this message translates to:
  /// **'None of the loaded resolver plugins returned a strong enough match.'**
  String get smartReplaceNoMatchSubtitle;

  /// No description provided for @smartReplaceBestMatch.
  ///
  /// In en, this message translates to:
  /// **'Best match'**
  String get smartReplaceBestMatch;

  /// No description provided for @smartReplaceSearchFailed.
  ///
  /// In en, this message translates to:
  /// **'Search failed'**
  String get smartReplaceSearchFailed;

  /// No description provided for @smartReplaceApplyFailed.
  ///
  /// In en, this message translates to:
  /// **'Smart Replace failed: {error}'**
  String smartReplaceApplyFailed(String error);

  /// No description provided for @smartReplaceApplied.
  ///
  /// In en, this message translates to:
  /// **'Applied replacement{queue}.'**
  String smartReplaceApplied(String queue);

  /// No description provided for @smartReplaceQueueUpdated.
  ///
  /// In en, this message translates to:
  /// **' and updated the queue'**
  String get smartReplaceQueueUpdated;

  /// No description provided for @playerUnknownQueue.
  ///
  /// In en, this message translates to:
  /// **'Unknown'**
  String get playerUnknownQueue;

  /// No description provided for @playerLiked.
  ///
  /// In en, this message translates to:
  /// **'{title} added to favorites'**
  String playerLiked(String title);

  /// No description provided for @playerUnliked.
  ///
  /// In en, this message translates to:
  /// **'{title} removed from favorites'**
  String playerUnliked(String title);

  /// No description provided for @offlineNoDownloads.
  ///
  /// In en, this message translates to:
  /// **'No Downloads'**
  String get offlineNoDownloads;

  /// No description provided for @offlineTitle.
  ///
  /// In en, this message translates to:
  /// **'Offline'**
  String get offlineTitle;

  /// No description provided for @offlineSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search your songs...'**
  String get offlineSearchHint;

  /// No description provided for @offlineRefreshTooltip.
  ///
  /// In en, this message translates to:
  /// **'Refresh Downloads'**
  String get offlineRefreshTooltip;

  /// No description provided for @offlineCloseSearch.
  ///
  /// In en, this message translates to:
  /// **'Close Search'**
  String get offlineCloseSearch;

  /// No description provided for @offlineSearchTooltip.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get offlineSearchTooltip;

  /// No description provided for @offlineOpenFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to open this offline track. Try refreshing downloads.'**
  String get offlineOpenFailed;

  /// No description provided for @offlinePlayFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not play this offline song. Please try again.'**
  String get offlinePlayFailed;

  /// No description provided for @albumViewTrackCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 Track} other{{count} Tracks}}'**
  String albumViewTrackCount(int count);

  /// No description provided for @albumViewLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to load album'**
  String get albumViewLoadFailed;

  /// No description provided for @aboutCraftingSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Built for music.'**
  String get aboutCraftingSubtitle;

  /// No description provided for @aboutFollowGitHub.
  ///
  /// In en, this message translates to:
  /// **'Follow him on GitHub'**
  String get aboutFollowGitHub;

  /// No description provided for @aboutSendInquiry.
  ///
  /// In en, this message translates to:
  /// **'Send a business inquiry'**
  String get aboutSendInquiry;

  /// No description provided for @aboutCreativeHighlights.
  ///
  /// In en, this message translates to:
  /// **'Updates and creative highlights'**
  String get aboutCreativeHighlights;

  /// No description provided for @aboutTipQuote.
  ///
  /// In en, this message translates to:
  /// **'Enjoying CNMW Music? You can support its development.'**
  String get aboutTipQuote;

  /// No description provided for @aboutTipButton.
  ///
  /// In en, this message translates to:
  /// **'Support the project'**
  String get aboutTipButton;

  /// No description provided for @aboutTipDesc.
  ///
  /// In en, this message translates to:
  /// **'Your contribution helps improve CNMW Music.'**
  String get aboutTipDesc;

  /// No description provided for @aboutGitHub.
  ///
  /// In en, this message translates to:
  /// **'GitHub'**
  String get aboutGitHub;

  /// No description provided for @songInfoSectionDetails.
  ///
  /// In en, this message translates to:
  /// **'Song Details'**
  String get songInfoSectionDetails;

  /// No description provided for @songInfoSectionTechnical.
  ///
  /// In en, this message translates to:
  /// **'Technical Info'**
  String get songInfoSectionTechnical;

  /// No description provided for @songInfoSectionActions.
  ///
  /// In en, this message translates to:
  /// **'Actions'**
  String get songInfoSectionActions;

  /// No description provided for @songInfoLabelTitle.
  ///
  /// In en, this message translates to:
  /// **'Title'**
  String get songInfoLabelTitle;

  /// No description provided for @songInfoLabelArtist.
  ///
  /// In en, this message translates to:
  /// **'Artist'**
  String get songInfoLabelArtist;

  /// No description provided for @songInfoLabelAlbum.
  ///
  /// In en, this message translates to:
  /// **'Album'**
  String get songInfoLabelAlbum;

  /// No description provided for @songInfoLabelDuration.
  ///
  /// In en, this message translates to:
  /// **'Duration'**
  String get songInfoLabelDuration;

  /// No description provided for @songInfoLabelSource.
  ///
  /// In en, this message translates to:
  /// **'Source'**
  String get songInfoLabelSource;

  /// No description provided for @songInfoLabelMediaId.
  ///
  /// In en, this message translates to:
  /// **'Media ID'**
  String get songInfoLabelMediaId;

  /// No description provided for @songInfoLabelPluginId.
  ///
  /// In en, this message translates to:
  /// **'Plugin ID'**
  String get songInfoLabelPluginId;

  /// No description provided for @songInfoCopyId.
  ///
  /// In en, this message translates to:
  /// **'Copy ID'**
  String get songInfoCopyId;

  /// No description provided for @songInfoCopyLink.
  ///
  /// In en, this message translates to:
  /// **'Copy Link'**
  String get songInfoCopyLink;

  /// No description provided for @songInfoOpenBrowser.
  ///
  /// In en, this message translates to:
  /// **'Open in browser'**
  String get songInfoOpenBrowser;

  /// No description provided for @songInfoIdCopied.
  ///
  /// In en, this message translates to:
  /// **'Media ID copied'**
  String get songInfoIdCopied;

  /// No description provided for @songInfoLinkCopied.
  ///
  /// In en, this message translates to:
  /// **'Link copied'**
  String get songInfoLinkCopied;

  /// No description provided for @songInfoNoLink.
  ///
  /// In en, this message translates to:
  /// **'No link available'**
  String get songInfoNoLink;

  /// No description provided for @songInfoOpenFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not open link'**
  String get songInfoOpenFailed;

  /// No description provided for @songInfoUpdateMetadata.
  ///
  /// In en, this message translates to:
  /// **'Get latest metadata'**
  String get songInfoUpdateMetadata;

  /// No description provided for @songInfoMetadataUpdated.
  ///
  /// In en, this message translates to:
  /// **'Metadata updated'**
  String get songInfoMetadataUpdated;

  /// No description provided for @songInfoMetadataUpdateFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not update metadata'**
  String get songInfoMetadataUpdateFailed;

  /// No description provided for @songInfoMetadataUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Metadata refresh is unavailable for this source'**
  String get songInfoMetadataUnavailable;

  /// No description provided for @songInfoSearchTitle.
  ///
  /// In en, this message translates to:
  /// **'Search for this song in CNMW Music'**
  String get songInfoSearchTitle;

  /// No description provided for @songInfoSearchArtist.
  ///
  /// In en, this message translates to:
  /// **'Search for this artist in CNMW Music'**
  String get songInfoSearchArtist;

  /// No description provided for @songInfoSearchAlbum.
  ///
  /// In en, this message translates to:
  /// **'Search for this album in CNMW Music'**
  String get songInfoSearchAlbum;

  /// No description provided for @eqTitle.
  ///
  /// In en, this message translates to:
  /// **'Equalizer'**
  String get eqTitle;

  /// No description provided for @chartNoItems.
  ///
  /// In en, this message translates to:
  /// **'No items in this chart'**
  String get chartNoItems;

  /// No description provided for @chartLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to load chart'**
  String get chartLoadFailed;

  /// No description provided for @chartPlay.
  ///
  /// In en, this message translates to:
  /// **'Play'**
  String get chartPlay;

  /// No description provided for @chartResolving.
  ///
  /// In en, this message translates to:
  /// **'Resolving'**
  String get chartResolving;

  /// No description provided for @chartReady.
  ///
  /// In en, this message translates to:
  /// **'Ready'**
  String get chartReady;

  /// No description provided for @chartAddToPlaylist.
  ///
  /// In en, this message translates to:
  /// **'Add to Playlist'**
  String get chartAddToPlaylist;

  /// No description provided for @chartNoResolver.
  ///
  /// In en, this message translates to:
  /// **'No content resolver loaded. Install a plugin to play.'**
  String get chartNoResolver;

  /// No description provided for @chartResolveFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not resolve. Searching instead...'**
  String get chartResolveFailed;

  /// No description provided for @chartNoResolverAdd.
  ///
  /// In en, this message translates to:
  /// **'No content resolver loaded.'**
  String get chartNoResolverAdd;

  /// No description provided for @chartNoMatch.
  ///
  /// In en, this message translates to:
  /// **'Could not find a match. Try searching manually.'**
  String get chartNoMatch;

  /// No description provided for @chartStatPeak.
  ///
  /// In en, this message translates to:
  /// **'Peak'**
  String get chartStatPeak;

  /// No description provided for @chartStatWeeks.
  ///
  /// In en, this message translates to:
  /// **'Weeks'**
  String get chartStatWeeks;

  /// No description provided for @chartStatChange.
  ///
  /// In en, this message translates to:
  /// **'Change'**
  String get chartStatChange;

  /// No description provided for @menuSharePreparing.
  ///
  /// In en, this message translates to:
  /// **'Preparing {title} for share.'**
  String menuSharePreparing(String title);

  /// No description provided for @menuOpenLinkFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not open link'**
  String get menuOpenLinkFailed;

  /// No description provided for @localMusicFolders.
  ///
  /// In en, this message translates to:
  /// **'Music Folders'**
  String get localMusicFolders;

  /// No description provided for @localMusicRemoveFolder.
  ///
  /// In en, this message translates to:
  /// **'Remove folder'**
  String get localMusicRemoveFolder;

  /// No description provided for @localMusicCloseSearch.
  ///
  /// In en, this message translates to:
  /// **'Close search'**
  String get localMusicCloseSearch;

  /// No description provided for @localMusicOpenSearch.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get localMusicOpenSearch;

  /// No description provided for @localMusicNoMusicFound.
  ///
  /// In en, this message translates to:
  /// **'No local music found'**
  String get localMusicNoMusicFound;

  /// No description provided for @localMusicNoSearchResults.
  ///
  /// In en, this message translates to:
  /// **'No tracks found matching your search.'**
  String get localMusicNoSearchResults;

  /// No description provided for @localMusicTrackCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 track} other{{count} tracks}}'**
  String localMusicTrackCount(int count);

  /// No description provided for @importSongsTitle.
  ///
  /// In en, this message translates to:
  /// **'Import Songs'**
  String get importSongsTitle;

  /// No description provided for @importNoPluginsLoaded.
  ///
  /// In en, this message translates to:
  /// **'No content-importer plugins loaded.\nInstall an importer plugin to import playlists from external services.'**
  String get importNoPluginsLoaded;

  /// No description provided for @importCNMW MusicFiles.
  ///
  /// In en, this message translates to:
  /// **'Import CNMW Music Files'**
  String get importCNMW MusicFiles;

  /// No description provided for @importM3UFiles.
  ///
  /// In en, this message translates to:
  /// **'Import M3U Playlist'**
  String get importM3UFiles;

  /// No description provided for @importM3UNameDialogTitle.
  ///
  /// In en, this message translates to:
  /// **'Playlist Name'**
  String get importM3UNameDialogTitle;

  /// No description provided for @importM3UNameHint.
  ///
  /// In en, this message translates to:
  /// **'Enter a name for this playlist'**
  String get importM3UNameHint;

  /// No description provided for @importM3UNoTracks.
  ///
  /// In en, this message translates to:
  /// **'No valid tracks found in the M3U file.'**
  String get importM3UNoTracks;

  /// No description provided for @importNoteTitle.
  ///
  /// In en, this message translates to:
  /// **'Note'**
  String get importNoteTitle;

  /// No description provided for @importNoteMessage.
  ///
  /// In en, this message translates to:
  /// **'You can only import files created by CNMW Music.\nIf your file is from another source, it will not work. Continue anyway?'**
  String get importNoteMessage;

  /// No description provided for @importTitle.
  ///
  /// In en, this message translates to:
  /// **'Import'**
  String get importTitle;

  /// No description provided for @importCheckingUrl.
  ///
  /// In en, this message translates to:
  /// **'Checking URL...'**
  String get importCheckingUrl;

  /// No description provided for @importFetchingTracks.
  ///
  /// In en, this message translates to:
  /// **'Fetching tracks...'**
  String get importFetchingTracks;

  /// No description provided for @importSavingToLibrary.
  ///
  /// In en, this message translates to:
  /// **'Saving to library...'**
  String get importSavingToLibrary;

  /// No description provided for @importPasteUrlHint.
  ///
  /// In en, this message translates to:
  /// **'Paste a playlist or album URL to import'**
  String get importPasteUrlHint;

  /// No description provided for @importAction.
  ///
  /// In en, this message translates to:
  /// **'Import'**
  String get importAction;

  /// No description provided for @importTrackCount.
  ///
  /// In en, this message translates to:
  /// **'{count} tracks'**
  String importTrackCount(int count);

  /// No description provided for @importResolvingProgress.
  ///
  /// In en, this message translates to:
  /// **'Resolving tracks: {done} / {total}'**
  String importResolvingProgress(int done, int total);

  /// No description provided for @importSaveTracks.
  ///
  /// In en, this message translates to:
  /// **'Save {count} Tracks'**
  String importSaveTracks(int count);

  /// No description provided for @importTracksSaved.
  ///
  /// In en, this message translates to:
  /// **'{count} tracks saved!'**
  String importTracksSaved(int count);

  /// No description provided for @importDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get importDone;

  /// No description provided for @importMore.
  ///
  /// In en, this message translates to:
  /// **'Import More'**
  String get importMore;

  /// No description provided for @importUnknownError.
  ///
  /// In en, this message translates to:
  /// **'Unknown error'**
  String get importUnknownError;

  /// No description provided for @importTryAgain.
  ///
  /// In en, this message translates to:
  /// **'Try Again'**
  String get importTryAgain;

  /// No description provided for @importSkipTrack.
  ///
  /// In en, this message translates to:
  /// **'Skip this track'**
  String get importSkipTrack;

  /// No description provided for @importMatchOptions.
  ///
  /// In en, this message translates to:
  /// **'Match options'**
  String get importMatchOptions;

  /// No description provided for @importSkipped.
  ///
  /// In en, this message translates to:
  /// **'Skipped'**
  String get importSkipped;

  /// No description provided for @importReorderTip.
  ///
  /// In en, this message translates to:
  /// **'Long press a playlist to start reordering'**
  String get importReorderTip;

  /// No description provided for @importErrorCannotHandleUrl.
  ///
  /// In en, this message translates to:
  /// **'This plugin cannot handle the provided URL.'**
  String get importErrorCannotHandleUrl;

  /// No description provided for @importErrorUnexpectedResponse.
  ///
  /// In en, this message translates to:
  /// **'Unexpected response from plugin.'**
  String get importErrorUnexpectedResponse;

  /// No description provided for @importErrorFailedToCheck.
  ///
  /// In en, this message translates to:
  /// **'Failed to check URL: {error}'**
  String importErrorFailedToCheck(String error);

  /// No description provided for @importErrorFailedToFetchInfo.
  ///
  /// In en, this message translates to:
  /// **'Failed to fetch collection info: {error}'**
  String importErrorFailedToFetchInfo(String error);

  /// No description provided for @importErrorFailedToFetchTracks.
  ///
  /// In en, this message translates to:
  /// **'Failed to fetch tracks: {error}'**
  String importErrorFailedToFetchTracks(String error);

  /// No description provided for @importErrorFailedToSave.
  ///
  /// In en, this message translates to:
  /// **'Failed to save playlist: {error}'**
  String importErrorFailedToSave(String error);

  /// No description provided for @playlistPinToTop.
  ///
  /// In en, this message translates to:
  /// **'Pin to Top'**
  String get playlistPinToTop;

  /// No description provided for @playlistUnpin.
  ///
  /// In en, this message translates to:
  /// **'Unpin'**
  String get playlistUnpin;

  /// No description provided for @snackbarInvalidFileFormat.
  ///
  /// In en, this message translates to:
  /// **'Invalid File Format'**
  String get snackbarInvalidFileFormat;

  /// No description provided for @snackbarProcessingFile.
  ///
  /// In en, this message translates to:
  /// **'Processing File...'**
  String get snackbarProcessingFile;

  /// No description provided for @pluginManagerTabInstalled.
  ///
  /// In en, this message translates to:
  /// **'Installed'**
  String get pluginManagerTabInstalled;

  /// No description provided for @pluginManagerTabStore.
  ///
  /// In en, this message translates to:
  /// **'Plugin Store'**
  String get pluginManagerTabStore;

  /// No description provided for @pluginManagerSelectPackage.
  ///
  /// In en, this message translates to:
  /// **'Select Plugin Package (.bex)'**
  String get pluginManagerSelectPackage;

  /// No description provided for @pluginManagerOutdatedManifest.
  ///
  /// In en, this message translates to:
  /// **'Plugin uses an outdated manifest version. Some features might break. Consider updating.'**
  String get pluginManagerOutdatedManifest;

  /// No description provided for @pluginManagerStatusActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get pluginManagerStatusActive;

  /// No description provided for @pluginManagerStatusInactive.
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get pluginManagerStatusInactive;

  /// No description provided for @pluginRepositoryAddTitle.
  ///
  /// In en, this message translates to:
  /// **'Add Repository'**
  String get pluginRepositoryAddTitle;

  /// No description provided for @pluginRepositoryAddSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enter the URL of a valid plugin repository JSON file.'**
  String get pluginRepositoryAddSubtitle;

  /// No description provided for @pluginRepositoryAddAction.
  ///
  /// In en, this message translates to:
  /// **'Add Repository'**
  String get pluginRepositoryAddAction;

  /// No description provided for @pluginRepositoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Plugin Repositories'**
  String get pluginRepositoryTitle;

  /// No description provided for @pluginRepositorySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Add a JSON source to browse remote plugins.'**
  String get pluginRepositorySubtitle;

  /// No description provided for @pluginRepositoryEmpty.
  ///
  /// In en, this message translates to:
  /// **'No repositories added yet.'**
  String get pluginRepositoryEmpty;

  /// No description provided for @pluginRepositoryUnknownUpdate.
  ///
  /// In en, this message translates to:
  /// **'Unknown update'**
  String get pluginRepositoryUnknownUpdate;

  /// No description provided for @pluginRepositoryNoDescription.
  ///
  /// In en, this message translates to:
  /// **'No description provided.'**
  String get pluginRepositoryNoDescription;

  /// No description provided for @pluginRepositoryUrlCopied.
  ///
  /// In en, this message translates to:
  /// **'Repository URL copied to clipboard'**
  String get pluginRepositoryUrlCopied;

  /// No description provided for @pluginRepositoryPluginsCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 plugin} other{{count} plugins}}'**
  String pluginRepositoryPluginsCount(int count);

  /// No description provided for @pluginRepositoryUpdatedOn.
  ///
  /// In en, this message translates to:
  /// **'Updated {date}'**
  String pluginRepositoryUpdatedOn(String date);

  /// No description provided for @pluginRepositoryAvailableCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 plugin available} other{{count} plugins available}}'**
  String pluginRepositoryAvailableCount(int count);

  /// No description provided for @pluginRepositoryOutdatedManifest.
  ///
  /// In en, this message translates to:
  /// **'Outdated manifest. Features may break.'**
  String get pluginRepositoryOutdatedManifest;

  /// No description provided for @pluginRepositoryUnknownPublisher.
  ///
  /// In en, this message translates to:
  /// **'Unknown publisher'**
  String get pluginRepositoryUnknownPublisher;

  /// No description provided for @pluginRepositoryActionRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get pluginRepositoryActionRetry;

  /// No description provided for @pluginRepositoryActionOutdated.
  ///
  /// In en, this message translates to:
  /// **'Outdated'**
  String get pluginRepositoryActionOutdated;

  /// No description provided for @pluginRepositoryActionInstalled.
  ///
  /// In en, this message translates to:
  /// **'Installed'**
  String get pluginRepositoryActionInstalled;

  /// No description provided for @pluginRepositoryActionInstall.
  ///
  /// In en, this message translates to:
  /// **'Install'**
  String get pluginRepositoryActionInstall;

  /// No description provided for @pluginRepositoryActionUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Unavailable'**
  String get pluginRepositoryActionUnavailable;

  /// No description provided for @pluginRepositoryInstallFailed.
  ///
  /// In en, this message translates to:
  /// **'Installation failed.'**
  String get pluginRepositoryInstallFailed;

  /// No description provided for @pluginRepositoryDownloadFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to download {name}.'**
  String pluginRepositoryDownloadFailed(String name);

  /// No description provided for @pluginRepositoryErrorLoad.
  ///
  /// In en, this message translates to:
  /// **'Failed to load repositories.'**
  String get pluginRepositoryErrorLoad;

  /// No description provided for @pluginRepositoryErrorInvalid.
  ///
  /// In en, this message translates to:
  /// **'Invalid repository URL or repository file.'**
  String get pluginRepositoryErrorInvalid;

  /// No description provided for @pluginRepositoryErrorRemove.
  ///
  /// In en, this message translates to:
  /// **'Failed to remove repository.'**
  String get pluginRepositoryErrorRemove;

  /// No description provided for @smartReplaceAppliedPlaylistsSummary.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{Replaced in 1 playlist{queue}.} other{Replaced in {count} playlists{queue}.}}'**
  String smartReplaceAppliedPlaylistsSummary(int count, String queue);

  /// No description provided for @lyricsSearchFieldLabel.
  ///
  /// In en, this message translates to:
  /// **'Search for lyrics...'**
  String get lyricsSearchFieldLabel;

  /// No description provided for @lyricsSearchEmptyPrompt.
  ///
  /// In en, this message translates to:
  /// **'Type a song or artist to find lyrics.'**
  String get lyricsSearchEmptyPrompt;

  /// No description provided for @lyricsSearchNoResults.
  ///
  /// In en, this message translates to:
  /// **'No lyrics found for \"{query}\"'**
  String lyricsSearchNoResults(String query);

  /// No description provided for @lyricsSearchApplied.
  ///
  /// In en, this message translates to:
  /// **'Lyrics successfully applied'**
  String get lyricsSearchApplied;

  /// No description provided for @lyricsSearchFetchFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to fetch lyrics'**
  String get lyricsSearchFetchFailed;

  /// No description provided for @lyricsSearchPreview.
  ///
  /// In en, this message translates to:
  /// **'Preview'**
  String get lyricsSearchPreview;

  /// No description provided for @lyricsSearchPreviewTooltip.
  ///
  /// In en, this message translates to:
  /// **'Preview lyrics'**
  String get lyricsSearchPreviewTooltip;

  /// No description provided for @lyricsSearchSynced.
  ///
  /// In en, this message translates to:
  /// **'SYNCED'**
  String get lyricsSearchSynced;

  /// No description provided for @lyricsSearchPreviewLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to load lyrics.'**
  String get lyricsSearchPreviewLoadFailed;

  /// No description provided for @lyricsSearchApplyAction.
  ///
  /// In en, this message translates to:
  /// **'Apply Lyrics'**
  String get lyricsSearchApplyAction;

  /// No description provided for @lyricsSettingsSearchTitle.
  ///
  /// In en, this message translates to:
  /// **'Search Custom Lyrics'**
  String get lyricsSettingsSearchTitle;

  /// No description provided for @lyricsSettingsSearchSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Find alternative versions online'**
  String get lyricsSettingsSearchSubtitle;

  /// No description provided for @lyricsSettingsSyncTitle.
  ///
  /// In en, this message translates to:
  /// **'Adjust Sync (Delay/Offset)'**
  String get lyricsSettingsSyncTitle;

  /// No description provided for @lyricsSettingsSyncSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Fix lyrics that are too fast or slow'**
  String get lyricsSettingsSyncSubtitle;

  /// No description provided for @lyricsSettingsSaveTitle.
  ///
  /// In en, this message translates to:
  /// **'Save Offline'**
  String get lyricsSettingsSaveTitle;

  /// No description provided for @lyricsSettingsSaveSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Store these lyrics on your device'**
  String get lyricsSettingsSaveSubtitle;

  /// No description provided for @lyricsSettingsDeleteTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete Saved Lyrics'**
  String get lyricsSettingsDeleteTitle;

  /// No description provided for @lyricsSettingsDeleteSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Remove offline lyrics data'**
  String get lyricsSettingsDeleteSubtitle;

  /// No description provided for @lyricsSyncTapToReset.
  ///
  /// In en, this message translates to:
  /// **'Tap to reset'**
  String get lyricsSyncTapToReset;

  /// No description provided for @upNextTitle.
  ///
  /// In en, this message translates to:
  /// **'Up Next'**
  String get upNextTitle;

  /// No description provided for @upNextItemsInQueue.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 item in queue} other{{count} items in queue}}'**
  String upNextItemsInQueue(int count);

  /// No description provided for @tooltipCopyToClipboard.
  ///
  /// In en, this message translates to:
  /// **'Copy to clipboard'**
  String get tooltipCopyToClipboard;

  /// No description provided for @snackbarCopiedToClipboard.
  ///
  /// In en, this message translates to:
  /// **'Copied to clipboard'**
  String get snackbarCopiedToClipboard;

  /// No description provided for @tooltipSongInfo.
  ///
  /// In en, this message translates to:
  /// **'Song Info'**
  String get tooltipSongInfo;

  /// No description provided for @snackbarCannotDeletePlayingSong.
  ///
  /// In en, this message translates to:
  /// **'Cannot delete currently playing song'**
  String get snackbarCannotDeletePlayingSong;

  /// No description provided for @playerLoopOff.
  ///
  /// In en, this message translates to:
  /// **'Off'**
  String get playerLoopOff;

  /// No description provided for @playerLoopOne.
  ///
  /// In en, this message translates to:
  /// **'Loop One'**
  String get playerLoopOne;

  /// No description provided for @playerLoopAll.
  ///
  /// In en, this message translates to:
  /// **'Loop All'**
  String get playerLoopAll;

  /// No description provided for @snackbarOpeningAlbumPage.
  ///
  /// In en, this message translates to:
  /// **'Opening original album page.'**
  String get snackbarOpeningAlbumPage;

  /// No description provided for @updateAvailableBody.
  ///
  /// In en, this message translates to:
  /// **'A new version of CNMW Music is available.\n\nVersion: {ver}+{build}'**
  String updateAvailableBody(String ver, String build);

  /// No description provided for @pluginSnackbarInstalled.
  ///
  /// In en, this message translates to:
  /// **'Plugin \"{id}\" installed successfully'**
  String pluginSnackbarInstalled(String id);

  /// No description provided for @pluginSnackbarDeleted.
  ///
  /// In en, this message translates to:
  /// **'Plugin \"{id}\" deleted successfully'**
  String pluginSnackbarDeleted(String id);

  /// No description provided for @pluginBootstrapTitle.
  ///
  /// In en, this message translates to:
  /// **'Setting up CNMW Music'**
  String get pluginBootstrapTitle;

  /// No description provided for @pluginBootstrapProgress.
  ///
  /// In en, this message translates to:
  /// **'Setting up new plugin engine... {percent}%'**
  String pluginBootstrapProgress(int percent);

  /// No description provided for @pluginBootstrapHint.
  ///
  /// In en, this message translates to:
  /// **'This only happens once.'**
  String get pluginBootstrapHint;

  /// No description provided for @backupSave.
  ///
  /// In en, this message translates to:
  /// **'Save backup as JSON'**
  String get backupSave;

  /// No description provided for @backupShare.
  ///
  /// In en, this message translates to:
  /// **'Share JSON backup'**
  String get backupShare;

  /// No description provided for @backupPortableDetails.
  ///
  /// In en, this message translates to:
  /// **'Includes playlists, likes, saved collections, histories and portable preferences. Audio files, accounts and device folders are excluded.'**
  String get backupPortableDetails;

  /// No description provided for @backupHistories.
  ///
  /// In en, this message translates to:
  /// **'Playback and search histories'**
  String get backupHistories;

  /// No description provided for @backupPreferences.
  ///
  /// In en, this message translates to:
  /// **'Portable preferences'**
  String get backupPreferences;

  /// No description provided for @backupNewCopy.
  ///
  /// In en, this message translates to:
  /// **'Import as new playlists'**
  String get backupNewCopy;

  /// No description provided for @backupMerge.
  ///
  /// In en, this message translates to:
  /// **'Merge with existing data'**
  String get backupMerge;

  /// No description provided for @backupReplace.
  ///
  /// In en, this message translates to:
  /// **'Replace selected sections'**
  String get backupReplace;

  /// No description provided for @backupMergeDetails.
  ///
  /// In en, this message translates to:
  /// **'Existing tracks, metadata and preferences are preserved. Missing tracks are appended in file order. Likes are merged.'**
  String get backupMergeDetails;

  /// No description provided for @backupReplaceWarning.
  ///
  /// In en, this message translates to:
  /// **'This replaces the selected sections, including existing playlists and likes when library is selected. Unselected sections and device files are preserved. A private recovery snapshot is created first.'**
  String get backupReplaceWarning;

  /// No description provided for @backupAutoDetails.
  ///
  /// In en, this message translates to:
  /// **'Keeps seven private recovery snapshots. Checked when the app opens, at most once per 24 hours. Private snapshots are removed on uninstall.'**
  String get backupAutoDetails;

  /// No description provided for @backupLocationDetails.
  ///
  /// In en, this message translates to:
  /// **'Choose a destination with Save backup. Private recovery snapshots are kept inside the app.'**
  String get backupLocationDetails;

  /// No description provided for @backupResetDetails.
  ///
  /// In en, this message translates to:
  /// **'Reset all database data on the next app start. Downloaded audio files and installed plugin files remain on this device. A private recovery snapshot is created first.'**
  String get backupResetDetails;

  /// No description provided for @backupResetPending.
  ///
  /// In en, this message translates to:
  /// **'Reset scheduled. Close and reopen CNMW Music to complete it.'**
  String get backupResetPending;

  /// No description provided for @backupPreviewCounts.
  ///
  /// In en, this message translates to:
  /// **'{playlists} playlists and {tracks} tracks'**
  String backupPreviewCounts(int playlists, int tracks);

  /// No description provided for @backupImportResult.
  ///
  /// In en, this message translates to:
  /// **'Import complete: {playlists} playlists created, {tracks} track entries added, {history} history records added and {settings} preferences applied.'**
  String backupImportResult(
      int playlists, int tracks, int history, int settings);

  /// No description provided for @backupRefreshFailed.
  ///
  /// In en, this message translates to:
  /// **'Data was imported. Close and reopen CNMW Music to refresh all preferences.'**
  String get backupRefreshFailed;

  /// No description provided for @backupRecoveryCopies.
  ///
  /// In en, this message translates to:
  /// **'Recovery copies'**
  String get backupRecoveryCopies;

  /// No description provided for @backupNoRecoveryCopies.
  ///
  /// In en, this message translates to:
  /// **'No recovery copies yet.'**
  String get backupNoRecoveryCopies;

  /// No description provided for @backupRecoveryAutomatic.
  ///
  /// In en, this message translates to:
  /// **'Automatic backup'**
  String get backupRecoveryAutomatic;

  /// No description provided for @backupRecoveryBeforeImport.
  ///
  /// In en, this message translates to:
  /// **'Before an import'**
  String get backupRecoveryBeforeImport;

  /// No description provided for @backupRecoveryBeforeReset.
  ///
  /// In en, this message translates to:
  /// **'Before a reset'**
  String get backupRecoveryBeforeReset;

  /// No description provided for @backupCancelReset.
  ///
  /// In en, this message translates to:
  /// **'Cancel reset'**
  String get backupCancelReset;

  /// No description provided for @libraryRecoveryTitle.
  ///
  /// In en, this message translates to:
  /// **'Recover missing library'**
  String get libraryRecoveryTitle;

  /// No description provided for @libraryRecoverySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Look for playlists and download records retained from earlier versions.'**
  String get libraryRecoverySubtitle;

  /// No description provided for @libraryRecoveryChooseSource.
  ///
  /// In en, this message translates to:
  /// **'Choose a retained database to scan. Your current library and original files will be preserved.'**
  String get libraryRecoveryChooseSource;

  /// No description provided for @libraryRecoveryNoSources.
  ///
  /// In en, this message translates to:
  /// **'No retained databases were found. Audio files alone cannot restore original playlist membership.'**
  String get libraryRecoveryNoSources;

  /// No description provided for @libraryRecoverySummary.
  ///
  /// In en, this message translates to:
  /// **'Found {tracks} tracks, {playlists} playlists and {downloads} download records. {unavailable} files are currently unavailable; their records will be preserved.'**
  String libraryRecoverySummary(
      int tracks, int playlists, int downloads, int unavailable);

  /// No description provided for @libraryRecoveryWarnings.
  ///
  /// In en, this message translates to:
  /// **'{broken} broken playlist references could not be reconstructed from this copy.'**
  String libraryRecoveryWarnings(int broken);

  /// No description provided for @libraryRecoveryMergeDetails.
  ///
  /// In en, this message translates to:
  /// **'Recovery adds missing tracks, playlist entries and download records. Existing playlists, file mappings and settings are preserved. A recovery copy is created first. Repeat this with another retained copy if it contains more of your library.'**
  String get libraryRecoveryMergeDetails;

  /// No description provided for @libraryRecoveryMerge.
  ///
  /// In en, this message translates to:
  /// **'Merge recovered library'**
  String get libraryRecoveryMerge;

  /// No description provided for @libraryRecoveryComplete.
  ///
  /// In en, this message translates to:
  /// **'Recovery complete: {entries} playlist entries and {downloads} download records added.'**
  String libraryRecoveryComplete(int entries, int downloads);

  /// No description provided for @backupStartupFailed.
  ///
  /// In en, this message translates to:
  /// **'CNMW Music could not start'**
  String get backupStartupFailed;

  /// No description provided for @backupStartupFailedDetails.
  ///
  /// In en, this message translates to:
  /// **'Startup stopped without automatically repairing or replacing your database. Close the app and retry. Keep your app data when reporting this error.'**
  String get backupStartupFailedDetails;

  /// No description provided for @lyricsTitle.
  ///
  /// In en, this message translates to:
  /// **'Lyrics'**
  String get lyricsTitle;

  /// No description provided for @lyricsEnterFullscreen.
  ///
  /// In en, this message translates to:
  /// **'Fullscreen lyrics'**
  String get lyricsEnterFullscreen;

  /// No description provided for @lyricsExitFullscreen.
  ///
  /// In en, this message translates to:
  /// **'Exit fullscreen'**
  String get lyricsExitFullscreen;

  /// No description provided for @lyricsFollowPlayback.
  ///
  /// In en, this message translates to:
  /// **'Follow playback'**
  String get lyricsFollowPlayback;

  /// No description provided for @lyricsTimingEarlier.
  ///
  /// In en, this message translates to:
  /// **'Earlier'**
  String get lyricsTimingEarlier;

  /// No description provided for @lyricsTimingLater.
  ///
  /// In en, this message translates to:
  /// **'Later'**
  String get lyricsTimingLater;

  /// No description provided for @lyricsTimingSave.
  ///
  /// In en, this message translates to:
  /// **'Save timing'**
  String get lyricsTimingSave;

  /// No description provided for @lyricsSaved.
  ///
  /// In en, this message translates to:
  /// **'Lyrics saved.'**
  String get lyricsSaved;

  /// No description provided for @lyricsSaveFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not save lyrics. Try again.'**
  String get lyricsSaveFailed;

  /// No description provided for @lyricsDeleteFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not delete saved lyrics. Try again.'**
  String get lyricsDeleteFailed;

  /// No description provided for @artistTopSongs.
  ///
  /// In en, this message translates to:
  /// **'Top songs'**
  String get artistTopSongs;

  /// No description provided for @artistLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to load artist'**
  String get artistLoadFailed;

  /// No description provided for @artistNoTopSongs.
  ///
  /// In en, this message translates to:
  /// **'No top songs available'**
  String get artistNoTopSongs;

  /// No description provided for @artistNoAlbums.
  ///
  /// In en, this message translates to:
  /// **'No albums available'**
  String get artistNoAlbums;

  /// No description provided for @snackbarOpeningArtistPage.
  ///
  /// In en, this message translates to:
  /// **'Opening original artist page.'**
  String get snackbarOpeningArtistPage;

  /// No description provided for @snackbarOpeningPlaylistPage.
  ///
  /// In en, this message translates to:
  /// **'Opening original playlist page.'**
  String get snackbarOpeningPlaylistPage;

  /// No description provided for @playlistSaveOrderFailed.
  ///
  /// In en, this message translates to:
  /// **'Unable to save playlist order. Please try again.'**
  String get playlistSaveOrderFailed;

  /// No description provided for @playlistReorderTracksHint.
  ///
  /// In en, this message translates to:
  /// **'Hold the handle to reorder tracks'**
  String get playlistReorderTracksHint;

  /// No description provided for @playlistTrackCountLabel.
  ///
  /// In en, this message translates to:
  /// **'Number of tracks'**
  String get playlistTrackCountLabel;

  /// No description provided for @playlistDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get playlistDescription;

  /// No description provided for @playlistOriginalUrl.
  ///
  /// In en, this message translates to:
  /// **'Original URL'**
  String get playlistOriginalUrl;

  /// No description provided for @searchSearching.
  ///
  /// In en, this message translates to:
  /// **'Searching…'**
  String get searchSearching;

  /// No description provided for @searchSuggestions.
  ///
  /// In en, this message translates to:
  /// **'Suggestions'**
  String get searchSuggestions;

  /// No description provided for @searchTopResults.
  ///
  /// In en, this message translates to:
  /// **'Top results'**
  String get searchTopResults;

  /// No description provided for @changelogEmpty.
  ///
  /// In en, this message translates to:
  /// **'No changelog information available.'**
  String get changelogEmpty;

  /// No description provided for @changelogTitle.
  ///
  /// In en, this message translates to:
  /// **'What\'s new'**
  String get changelogTitle;

  /// No description provided for @changelogLatest.
  ///
  /// In en, this message translates to:
  /// **'Latest'**
  String get changelogLatest;

  /// No description provided for @changelogNext.
  ///
  /// In en, this message translates to:
  /// **'Next version'**
  String get changelogNext;

  /// No description provided for @changelogVersion.
  ///
  /// In en, this message translates to:
  /// **'Version {version}'**
  String changelogVersion(String version);

  /// No description provided for @pluginBootstrapIncomplete.
  ///
  /// In en, this message translates to:
  /// **'Setup incomplete'**
  String get pluginBootstrapIncomplete;

  /// No description provided for @pluginBootstrapRetryBody.
  ///
  /// In en, this message translates to:
  /// **'Some plugins could not be installed right now. Retry to finish setup.'**
  String get pluginBootstrapRetryBody;

  /// No description provided for @pluginBootstrapInternetTitle.
  ///
  /// In en, this message translates to:
  /// **'Internet required'**
  String get pluginBootstrapInternetTitle;

  /// No description provided for @pluginBootstrapInternetBody.
  ///
  /// In en, this message translates to:
  /// **'CNMW Music needs an internet connection once to detect your country and set up the plugin engine.'**
  String get pluginBootstrapInternetBody;

  /// No description provided for @buttonExit.
  ///
  /// In en, this message translates to:
  /// **'Exit'**
  String get buttonExit;

  /// No description provided for @eqSource.
  ///
  /// In en, this message translates to:
  /// **'Equalizer source'**
  String get eqSource;

  /// No description provided for @eqBuiltin.
  ///
  /// In en, this message translates to:
  /// **'In-app equalizer'**
  String get eqBuiltin;

  /// No description provided for @eqBuiltinSubtitle.
  ///
  /// In en, this message translates to:
  /// **'10-band equalizer'**
  String get eqBuiltinSubtitle;

  /// No description provided for @eqDevice.
  ///
  /// In en, this message translates to:
  /// **'Device equalizer'**
  String get eqDevice;

  /// No description provided for @eqDeviceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'System / Dolby Atmos'**
  String get eqDeviceSubtitle;

  /// No description provided for @eqDeviceHint.
  ///
  /// In en, this message translates to:
  /// **'The in-app equalizer is disabled. Configure your device equalizer in your device\'s sound settings.'**
  String get eqDeviceHint;

  /// No description provided for @eqPresets.
  ///
  /// In en, this message translates to:
  /// **'Presets'**
  String get eqPresets;

  /// No description provided for @eqCustomCurve.
  ///
  /// In en, this message translates to:
  /// **'Custom curve'**
  String get eqCustomCurve;

  /// No description provided for @shortcutMuted.
  ///
  /// In en, this message translates to:
  /// **'Muted'**
  String get shortcutMuted;

  /// No description provided for @shortcutUnmuted.
  ///
  /// In en, this message translates to:
  /// **'Unmuted'**
  String get shortcutUnmuted;

  /// No description provided for @shortcutShuffleOn.
  ///
  /// In en, this message translates to:
  /// **'Shuffle on'**
  String get shortcutShuffleOn;

  /// No description provided for @shortcutShuffleOff.
  ///
  /// In en, this message translates to:
  /// **'Shuffle off'**
  String get shortcutShuffleOff;

  /// No description provided for @shortcutRepeatOff.
  ///
  /// In en, this message translates to:
  /// **'Repeat off'**
  String get shortcutRepeatOff;

  /// No description provided for @shortcutLiked.
  ///
  /// In en, this message translates to:
  /// **'Added to favorites'**
  String get shortcutLiked;

  /// No description provided for @shortcutUnliked.
  ///
  /// In en, this message translates to:
  /// **'Removed from favorites'**
  String get shortcutUnliked;

  /// No description provided for @downloadFolderSelectFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not select download folder: {error}'**
  String downloadFolderSelectFailed(String error);

  /// No description provided for @aboutVersionUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Version unavailable'**
  String get aboutVersionUnavailable;

  /// No description provided for @backupNewCopyDetails.
  ///
  /// In en, this message translates to:
  /// **'Creates separate playlists and merges favorites. Existing playlists are preserved. Selected histories and preferences are also imported.'**
  String get backupNewCopyDetails;

  /// No description provided for @changelogCurrent.
  ///
  /// In en, this message translates to:
  /// **'Current'**
  String get changelogCurrent;

  /// No description provided for @backupLibrary.
  ///
  /// In en, this message translates to:
  /// **'Library (playlists, favorites and saved collections)'**
  String get backupLibrary;

  /// No description provided for @eqPresetFlat.
  ///
  /// In en, this message translates to:
  /// **'Flat'**
  String get eqPresetFlat;

  /// No description provided for @eqPresetAcoustic.
  ///
  /// In en, this message translates to:
  /// **'Acoustic'**
  String get eqPresetAcoustic;

  /// No description provided for @eqPresetBassBoost.
  ///
  /// In en, this message translates to:
  /// **'Bass boost'**
  String get eqPresetBassBoost;

  /// No description provided for @eqPresetBassReducer.
  ///
  /// In en, this message translates to:
  /// **'Bass reduction'**
  String get eqPresetBassReducer;

  /// No description provided for @eqPresetClassical.
  ///
  /// In en, this message translates to:
  /// **'Classical'**
  String get eqPresetClassical;

  /// No description provided for @eqPresetDance.
  ///
  /// In en, this message translates to:
  /// **'Dance'**
  String get eqPresetDance;

  /// No description provided for @eqPresetDeep.
  ///
  /// In en, this message translates to:
  /// **'Deep'**
  String get eqPresetDeep;

  /// No description provided for @eqPresetEDM.
  ///
  /// In en, this message translates to:
  /// **'EDM'**
  String get eqPresetEDM;

  /// No description provided for @eqPresetElectronic.
  ///
  /// In en, this message translates to:
  /// **'Electronic'**
  String get eqPresetElectronic;

  /// No description provided for @eqPresetHipHop.
  ///
  /// In en, this message translates to:
  /// **'Hip-hop'**
  String get eqPresetHipHop;

  /// No description provided for @eqPresetJazz.
  ///
  /// In en, this message translates to:
  /// **'Jazz'**
  String get eqPresetJazz;

  /// No description provided for @eqPresetLatin.
  ///
  /// In en, this message translates to:
  /// **'Latin'**
  String get eqPresetLatin;

  /// No description provided for @eqPresetLive.
  ///
  /// In en, this message translates to:
  /// **'Live'**
  String get eqPresetLive;

  /// No description provided for @eqPresetLounge.
  ///
  /// In en, this message translates to:
  /// **'Lounge'**
  String get eqPresetLounge;

  /// No description provided for @eqPresetMetal.
  ///
  /// In en, this message translates to:
  /// **'Metal'**
  String get eqPresetMetal;

  /// No description provided for @eqPresetPiano.
  ///
  /// In en, this message translates to:
  /// **'Piano'**
  String get eqPresetPiano;

  /// No description provided for @eqPresetPop.
  ///
  /// In en, this message translates to:
  /// **'Pop'**
  String get eqPresetPop;

  /// No description provided for @eqPresetRB.
  ///
  /// In en, this message translates to:
  /// **'R&B'**
  String get eqPresetRB;

  /// No description provided for @eqPresetRock.
  ///
  /// In en, this message translates to:
  /// **'Rock'**
  String get eqPresetRock;

  /// No description provided for @eqPresetSmallSpeakers.
  ///
  /// In en, this message translates to:
  /// **'Small speakers'**
  String get eqPresetSmallSpeakers;

  /// No description provided for @eqPresetSpokenWord.
  ///
  /// In en, this message translates to:
  /// **'Spoken word'**
  String get eqPresetSpokenWord;

  /// No description provided for @eqPresetTrebleBoost.
  ///
  /// In en, this message translates to:
  /// **'Treble boost'**
  String get eqPresetTrebleBoost;

  /// No description provided for @eqPresetTrebleReducer.
  ///
  /// In en, this message translates to:
  /// **'Treble reduction'**
  String get eqPresetTrebleReducer;

  /// No description provided for @eqPresetVocalBooster.
  ///
  /// In en, this message translates to:
  /// **'Vocal boost'**
  String get eqPresetVocalBooster;

  /// No description provided for @eqPresetCustom.
  ///
  /// In en, this message translates to:
  /// **'Custom'**
  String get eqPresetCustom;

  /// No description provided for @lastfmStatusSection.
  ///
  /// In en, this message translates to:
  /// **'Scrobble status'**
  String get lastfmStatusSection;

  /// No description provided for @lastfmStatusSynced.
  ///
  /// In en, this message translates to:
  /// **'All caught up'**
  String get lastfmStatusSynced;

  /// No description provided for @lastfmStatusSending.
  ///
  /// In en, this message translates to:
  /// **'Sending…'**
  String get lastfmStatusSending;

  /// No description provided for @lastfmStatusQueued.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 scrobble waiting} other{{count} scrobbles waiting}}'**
  String lastfmStatusQueued(int count);

  /// No description provided for @lastfmStatusRetrying.
  ///
  /// In en, this message translates to:
  /// **'Offline · will retry shortly'**
  String get lastfmStatusRetrying;

  /// No description provided for @lastfmStatusAuthPaused.
  ///
  /// In en, this message translates to:
  /// **'Paused · sign in again'**
  String get lastfmStatusAuthPaused;

  /// No description provided for @lastfmStatusOff.
  ///
  /// In en, this message translates to:
  /// **'Scrobbling is turned off'**
  String get lastfmStatusOff;

  /// No description provided for @lastfmStatQueued.
  ///
  /// In en, this message translates to:
  /// **'Queued'**
  String get lastfmStatQueued;

  /// No description provided for @lastfmStatLastSent.
  ///
  /// In en, this message translates to:
  /// **'Last sent'**
  String get lastfmStatLastSent;

  /// No description provided for @lastfmNever.
  ///
  /// In en, this message translates to:
  /// **'Never'**
  String get lastfmNever;

  /// No description provided for @lastfmJustNow.
  ///
  /// In en, this message translates to:
  /// **'Just now'**
  String get lastfmJustNow;

  /// No description provided for @lastfmMinutesAgo.
  ///
  /// In en, this message translates to:
  /// **'{n}m ago'**
  String lastfmMinutesAgo(int n);

  /// No description provided for @lastfmHoursAgo.
  ///
  /// In en, this message translates to:
  /// **'{n}h ago'**
  String lastfmHoursAgo(int n);

  /// No description provided for @lastfmDaysAgo.
  ///
  /// In en, this message translates to:
  /// **'{n}d ago'**
  String lastfmDaysAgo(int n);

  /// No description provided for @lastfmLastTrack.
  ///
  /// In en, this message translates to:
  /// **'Last scrobbled'**
  String get lastfmLastTrack;

  /// No description provided for @lastfmErrorNetwork.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t reach Last.fm. Your scrobbles are safe and will be sent automatically.'**
  String get lastfmErrorNetwork;

  /// No description provided for @lastfmErrorAuth.
  ///
  /// In en, this message translates to:
  /// **'Your Last.fm session is no longer valid. Remove the keys and authenticate again.'**
  String get lastfmErrorAuth;

  /// No description provided for @lastfmErrorRejected.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{Last.fm rejected 1 scrobble and it was discarded.} other{Last.fm rejected {count} scrobbles and they were discarded.}}'**
  String lastfmErrorRejected(int count);

  /// No description provided for @lastfmSyncNow.
  ///
  /// In en, this message translates to:
  /// **'Sync now'**
  String get lastfmSyncNow;

  /// No description provided for @lastfmClearQueue.
  ///
  /// In en, this message translates to:
  /// **'Clear queue'**
  String get lastfmClearQueue;

  /// No description provided for @lastfmQueueCleared.
  ///
  /// In en, this message translates to:
  /// **'Scrobble queue cleared'**
  String get lastfmQueueCleared;

  /// No description provided for @settingsDiscord.
  ///
  /// In en, this message translates to:
  /// **'Discord'**
  String get settingsDiscord;

  /// No description provided for @settingsDiscordSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Rich Presence: show what you\'re listening to.'**
  String get settingsDiscordSubtitle;

  /// No description provided for @discordTitle.
  ///
  /// In en, this message translates to:
  /// **'Discord'**
  String get discordTitle;

  /// No description provided for @discordEnable.
  ///
  /// In en, this message translates to:
  /// **'Show on Discord'**
  String get discordEnable;

  /// No description provided for @discordEnableSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Share the song you\'re playing on your Discord profile.'**
  String get discordEnableSubtitle;

  /// No description provided for @discordStatusIdle.
  ///
  /// In en, this message translates to:
  /// **'Ready to share'**
  String get discordStatusIdle;

  /// No description provided for @discordStatusConnecting.
  ///
  /// In en, this message translates to:
  /// **'Connecting to Discord…'**
  String get discordStatusConnecting;

  /// No description provided for @discordStatusConnected.
  ///
  /// In en, this message translates to:
  /// **'Connected as {name}'**
  String discordStatusConnected(String name);

  /// No description provided for @discordStatusConnectedNoUser.
  ///
  /// In en, this message translates to:
  /// **'Connected to Discord'**
  String get discordStatusConnectedNoUser;

  /// No description provided for @discordStatusNotFound.
  ///
  /// In en, this message translates to:
  /// **'Discord isn\'t running'**
  String get discordStatusNotFound;

  /// No description provided for @discordStatusError.
  ///
  /// In en, this message translates to:
  /// **'Discord refused the connection'**
  String get discordStatusError;

  /// No description provided for @discordReconnect.
  ///
  /// In en, this message translates to:
  /// **'Reconnect'**
  String get discordReconnect;

  /// No description provided for @discordSectionPreview.
  ///
  /// In en, this message translates to:
  /// **'Preview'**
  String get discordSectionPreview;

  /// No description provided for @discordSectionCard.
  ///
  /// In en, this message translates to:
  /// **'Appearance'**
  String get discordSectionCard;

  /// No description provided for @discordSectionPrivacy.
  ///
  /// In en, this message translates to:
  /// **'Privacy'**
  String get discordSectionPrivacy;

  /// No description provided for @discordPreviewEmpty.
  ///
  /// In en, this message translates to:
  /// **'Play a song to preview your card.'**
  String get discordPreviewEmpty;

  /// No description provided for @discordKindListening.
  ///
  /// In en, this message translates to:
  /// **'Listening to CNMW Music'**
  String get discordKindListening;

  /// No description provided for @discordWhenPaused.
  ///
  /// In en, this message translates to:
  /// **'When paused'**
  String get discordWhenPaused;

  /// No description provided for @discordPausedKeep.
  ///
  /// In en, this message translates to:
  /// **'Keep showing'**
  String get discordPausedKeep;

  /// No description provided for @discordPausedHideLater.
  ///
  /// In en, this message translates to:
  /// **'Hide after 5 minutes'**
  String get discordPausedHideLater;

  /// No description provided for @discordPausedHide.
  ///
  /// In en, this message translates to:
  /// **'Hide right away'**
  String get discordPausedHide;

  /// No description provided for @discordShowArtwork.
  ///
  /// In en, this message translates to:
  /// **'Album artwork'**
  String get discordShowArtwork;

  /// No description provided for @discordShowArtworkSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Cover art with a play or pause badge.'**
  String get discordShowArtworkSubtitle;

  /// No description provided for @discordShowProgress.
  ///
  /// In en, this message translates to:
  /// **'Time bar'**
  String get discordShowProgress;

  /// No description provided for @discordShowProgressSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Live progress bar that follows seeks.'**
  String get discordShowProgressSubtitle;

  /// No description provided for @discordShowLinks.
  ///
  /// In en, this message translates to:
  /// **'Clickable links'**
  String get discordShowLinks;

  /// No description provided for @discordShowLinksSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Song, artist and album open their pages.'**
  String get discordShowLinksSubtitle;

  /// No description provided for @discordShareLocal.
  ///
  /// In en, this message translates to:
  /// **'Share local files'**
  String get discordShareLocal;

  /// No description provided for @discordShareLocalSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Also publish songs from your local library.'**
  String get discordShareLocalSubtitle;

  /// No description provided for @discordFooter.
  ///
  /// In en, this message translates to:
  /// **'Needs the Discord desktop app running on this computer. Changes apply instantly; Discord accepts about one update every 4 seconds.'**
  String get discordFooter;

  /// No description provided for @discordStatusRetry.
  ///
  /// In en, this message translates to:
  /// **'Retrying in {seconds}s'**
  String discordStatusRetry(int seconds);

  /// No description provided for @discordStatusIdleDetail.
  ///
  /// In en, this message translates to:
  /// **'Connects automatically when music plays.'**
  String get discordStatusIdleDetail;

  /// No description provided for @discordPausedKeepSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Shows a paused badge without the time bar.'**
  String get discordPausedKeepSubtitle;

  /// No description provided for @discordPausedHideLaterSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Short pauses keep your card, long ones clear it.'**
  String get discordPausedHideLaterSubtitle;

  /// No description provided for @discordPausedHideSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Clears the moment you pause.'**
  String get discordPausedHideSubtitle;

  /// No description provided for @discordPreviewCaption.
  ///
  /// In en, this message translates to:
  /// **'How friends see you on Discord.'**
  String get discordPreviewCaption;

  /// No description provided for @discordStatusText.
  ///
  /// In en, this message translates to:
  /// **'Status text'**
  String get discordStatusText;

  /// No description provided for @discordStatusTextSubtitle.
  ///
  /// In en, this message translates to:
  /// **'What friends see next to your name.'**
  String get discordStatusTextSubtitle;

  /// No description provided for @discordStatusTextApp.
  ///
  /// In en, this message translates to:
  /// **'App name'**
  String get discordStatusTextApp;

  /// No description provided for @discordStatusTextArtist.
  ///
  /// In en, this message translates to:
  /// **'Artist'**
  String get discordStatusTextArtist;

  /// No description provided for @discordStatusTextSong.
  ///
  /// In en, this message translates to:
  /// **'Song title'**
  String get discordStatusTextSong;

  /// No description provided for @libraryReorderHint.
  ///
  /// In en, this message translates to:
  /// **'Drag to reorder'**
  String get libraryReorderHint;

  /// No description provided for @libraryReorderHintPinned.
  ///
  /// In en, this message translates to:
  /// **'Drag to reorder. Pinned items stay on top.'**
  String get libraryReorderHintPinned;

  /// No description provided for @tooltipRemoveFromQueue.
  ///
  /// In en, this message translates to:
  /// **'Remove from queue'**
  String get tooltipRemoveFromQueue;

  /// No description provided for @windowMinimize.
  ///
  /// In en, this message translates to:
  /// **'Minimize'**
  String get windowMinimize;

  /// No description provided for @windowMaximize.
  ///
  /// In en, this message translates to:
  /// **'Maximize'**
  String get windowMaximize;

  /// No description provided for @windowRestore.
  ///
  /// In en, this message translates to:
  /// **'Restore Down'**
  String get windowRestore;

  /// No description provided for @windowClose.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get windowClose;

  /// No description provided for @settingsWindow.
  ///
  /// In en, this message translates to:
  /// **'Window & Tray'**
  String get settingsWindow;

  /// No description provided for @settingsWindowSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Close button, tray icon and background playback'**
  String get settingsWindowSubtitle;

  /// No description provided for @windowCloseSection.
  ///
  /// In en, this message translates to:
  /// **'When you close the window'**
  String get windowCloseSection;

  /// No description provided for @windowCloseTray.
  ///
  /// In en, this message translates to:
  /// **'Keep playing in the system tray'**
  String get windowCloseTray;

  /// No description provided for @windowCloseTrayMac.
  ///
  /// In en, this message translates to:
  /// **'Keep playing in the menu bar'**
  String get windowCloseTrayMac;

  /// No description provided for @windowCloseTraySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Hides the window and keeps the music going. Uses the fewest resources.'**
  String get windowCloseTraySubtitle;

  /// No description provided for @windowCloseMinimize.
  ///
  /// In en, this message translates to:
  /// **'Minimize the window'**
  String get windowCloseMinimize;

  /// No description provided for @windowCloseMinimizeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Keeps playing with the window minimized to the taskbar.'**
  String get windowCloseMinimizeSubtitle;

  /// No description provided for @windowCloseMinimizeSubtitleMac.
  ///
  /// In en, this message translates to:
  /// **'Keeps playing with the window minimized to the Dock.'**
  String get windowCloseMinimizeSubtitleMac;

  /// No description provided for @windowCloseQuit.
  ///
  /// In en, this message translates to:
  /// **'Quit CNMW Music'**
  String get windowCloseQuit;

  /// No description provided for @windowCloseQuitSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Stops playback and closes the app completely.'**
  String get windowCloseQuitSubtitle;

  /// No description provided for @windowTrayUnavailable.
  ///
  /// In en, this message translates to:
  /// **'No system tray is available, so closing minimizes the window instead.'**
  String get windowTrayUnavailable;

  /// No description provided for @windowTrayMenuSection.
  ///
  /// In en, this message translates to:
  /// **'Tray menu'**
  String get windowTrayMenuSection;

  /// No description provided for @windowTrayFootnote.
  ///
  /// In en, this message translates to:
  /// **'Click the tray icon to bring CNMW Music back, or right-click it for playback controls.'**
  String get windowTrayFootnote;

  /// No description provided for @windowTrayFootnoteMac.
  ///
  /// In en, this message translates to:
  /// **'Click the menu bar icon for playback controls or to bring CNMW Music back.'**
  String get windowTrayFootnoteMac;

  /// No description provided for @windowTrayFootnoteLinux.
  ///
  /// In en, this message translates to:
  /// **'Open the tray icon\'s menu for playback controls. On GNOME, tray icons need the AppIndicator extension.'**
  String get windowTrayFootnoteLinux;

  /// No description provided for @trayNothingPlaying.
  ///
  /// In en, this message translates to:
  /// **'Nothing playing'**
  String get trayNothingPlaying;

  /// No description provided for @trayPlay.
  ///
  /// In en, this message translates to:
  /// **'Play'**
  String get trayPlay;

  /// No description provided for @trayPause.
  ///
  /// In en, this message translates to:
  /// **'Pause'**
  String get trayPause;

  /// No description provided for @trayNext.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get trayNext;

  /// No description provided for @trayPrevious.
  ///
  /// In en, this message translates to:
  /// **'Previous'**
  String get trayPrevious;

  /// No description provided for @trayShowWindow.
  ///
  /// In en, this message translates to:
  /// **'Show CNMW Music'**
  String get trayShowWindow;

  /// No description provided for @trayHideWindow.
  ///
  /// In en, this message translates to:
  /// **'Hide CNMW Music'**
  String get trayHideWindow;

  /// No description provided for @trayQuit.
  ///
  /// In en, this message translates to:
  /// **'Quit CNMW Music'**
  String get trayQuit;

  /// No description provided for @feedKindAnnouncement.
  ///
  /// In en, this message translates to:
  /// **'News'**
  String get feedKindAnnouncement;

  /// No description provided for @feedKindApp.
  ///
  /// In en, this message translates to:
  /// **'New app'**
  String get feedKindApp;

  /// No description provided for @feedKindForm.
  ///
  /// In en, this message translates to:
  /// **'Sign up'**
  String get feedKindForm;

  /// No description provided for @feedKindNotice.
  ///
  /// In en, this message translates to:
  /// **'Important'**
  String get feedKindNotice;

  /// No description provided for @feedKindUpdate.
  ///
  /// In en, this message translates to:
  /// **'Update'**
  String get feedKindUpdate;

  /// No description provided for @feedUpdateTitle.
  ///
  /// In en, this message translates to:
  /// **'CNMW Music {version} is available'**
  String feedUpdateTitle(String version);

  /// No description provided for @feedUpdateBody.
  ///
  /// In en, this message translates to:
  /// **'See what\'s new and download it.'**
  String get feedUpdateBody;

  /// No description provided for @feedUpdateAction.
  ///
  /// In en, this message translates to:
  /// **'View update'**
  String get feedUpdateAction;

  /// No description provided for @feedOpen.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get feedOpen;

  /// No description provided for @feedDismiss.
  ///
  /// In en, this message translates to:
  /// **'Dismiss'**
  String get feedDismiss;

  /// No description provided for @feedNew.
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get feedNew;

  /// No description provided for @feedDraft.
  ///
  /// In en, this message translates to:
  /// **'Draft'**
  String get feedDraft;

  /// No description provided for @feedPreview.
  ///
  /// In en, this message translates to:
  /// **'Preview drafts'**
  String get feedPreview;

  /// No description provided for @feedEmpty.
  ///
  /// In en, this message translates to:
  /// **'You\'re all caught up'**
  String get feedEmpty;

  /// No description provided for @feedEmptySubtitle.
  ///
  /// In en, this message translates to:
  /// **'News, new apps and updates will show up here.'**
  String get feedEmptySubtitle;

  /// No description provided for @settingsNotifications.
  ///
  /// In en, this message translates to:
  /// **'Updates & news'**
  String get settingsNotifications;

  /// No description provided for @settingsNotificationsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Update alerts, news and announcements'**
  String get settingsNotificationsSubtitle;

  /// No description provided for @feedSection.
  ///
  /// In en, this message translates to:
  /// **'News & announcements'**
  String get feedSection;

  /// No description provided for @feedOnHome.
  ///
  /// In en, this message translates to:
  /// **'Show on Home'**
  String get feedOnHome;

  /// No description provided for @feedOnHomeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'A small card for news and new apps. Important notices always show.'**
  String get feedOnHomeSubtitle;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>[
        'de',
        'en',
        'es',
        'fr',
        'hi',
        'ja',
        'ko',
        'pt',
        'tr',
        'zh'
      ].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'de':
      return AppLocalizationsDe();
    case 'en':
      return AppLocalizationsEn();
    case 'es':
      return AppLocalizationsEs();
    case 'fr':
      return AppLocalizationsFr();
    case 'hi':
      return AppLocalizationsHi();
    case 'ja':
      return AppLocalizationsJa();
    case 'ko':
      return AppLocalizationsKo();
    case 'pt':
      return AppLocalizationsPt();
    case 'tr':
      return AppLocalizationsTr();
    case 'zh':
      return AppLocalizationsZh();
  }

  throw FlutterError(
      'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
      'an issue with the localizations generation tool. Please file an issue '
      'on GitHub with a reproducible sample app and the gen-l10n configuration '
      'that was used.');
}
