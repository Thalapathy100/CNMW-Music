import 'dart:io';

import 'package:Bloomee/blocs/settings_cubit/cubit/settings_cubit.dart';
import 'package:Bloomee/services/player/stream_quality_selector.dart';
import 'package:Bloomee/screens/screen/home_views/setting_views/setting_shared_widgets.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:Bloomee/core/theme/app_theme.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:Bloomee/l10n/app_localizations.dart';
import 'package:icons_plus/icons_plus.dart';
import 'package:Bloomee/services/download/download_storage.dart';
import 'package:Bloomee/screens/widgets/snackbar.dart';

class DownloadSettings extends StatefulWidget {
  const DownloadSettings({super.key});

  @override
  State<DownloadSettings> createState() => _DownloadSettingsState();
}

class _DownloadSettingsState extends State<DownloadSettings> {
  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: Default_Theme.themeColor,
      appBar: AppBar(
        backgroundColor: Default_Theme.themeColor,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        leadingWidth: 64,
        leading: Padding(
          padding: const EdgeInsets.only(left: 12.0),
          child: Center(
            child: IconButton(
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Default_Theme.primaryColor1,
                size: 24,
              ),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ),
        title: Text(
          l10n.downloadSettingTitle,
          style: const TextStyle(
            color: Default_Theme.primaryColor1,
            fontSize: 22,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
          ).merge(Default_Theme.secondoryTextStyleMedium),
        ),
      ),
      body: BlocBuilder<SettingsCubit, SettingsState>(
        builder: (context, state) {
          return ListView(
            physics: const BouncingScrollPhysics(),
            padding: settingsPagePadding(context),
            children: [
              SettingSectionHeader(label: l10n.settingsQuality),
              SettingCard(
                children: [
                  SettingQualityChipRow(
                    icon: MingCute.folder_download_fill,
                    title: l10n.downloadSettingQuality,
                    subtitle: l10n.downloadSettingQualitySubtitle,
                    options: AudioStreamQualityPreference.values
                        .map((q) => q.label)
                        .toList(),
                    selected: state.downQuality,
                    onSelected: (v) =>
                        context.read<SettingsCubit>().setDownQuality(v),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              SettingSectionHeader(label: l10n.settingsStorage),
              SettingCard(
                children: [
                  SettingNavTile(
                    icon: MingCute.folder_fill,
                    title: l10n.downloadSettingFolder,
                    subtitle: DownloadStorage.isDocument(state.downPath)
                        ? Uri.parse(state.downPath).pathSegments.last
                        : state.downPath,
                    onTap: () async {
                      final settings = context.read<SettingsCubit>();
                      try {
                        final value = Platform.isAndroid
                            ? await DownloadStorage.pickFolder()
                            : await FilePicker.platform.getDirectoryPath();
                        if (value != null) await settings.setDownPath(value);
                      } catch (error) {
                        SnackbarService.showMessage(
                            AppLocalizations.of(context)!
                                .downloadFolderSelectFailed(error.toString()));
                      }
                    },
                  ),
                  const SettingDivider(),
                  SettingNavTile(
                    icon: MingCute.refresh_1_line,
                    title: l10n.downloadSettingResetFolder,
                    subtitle: l10n.downloadSettingResetFolderSubtitle,
                    roundBottom: true,
                    onTap: () => context.read<SettingsCubit>().resetDownPath(),
                  ),
                ],
              ),
              const SizedBox(height: 40),
            ],
          );
        },
      ),
    );
  }
}
