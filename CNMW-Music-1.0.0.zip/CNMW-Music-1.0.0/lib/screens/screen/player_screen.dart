import 'dart:async';

import 'package:Bloomee/blocs/downloader/cubit/downloader_cubit.dart';
import 'package:Bloomee/blocs/library/cubit/library_items_cubit.dart';
import 'package:Bloomee/blocs/player_overlay/player_overlay_cubit.dart';
import 'package:Bloomee/core/adapters/track_adapter.dart';
import 'package:Bloomee/screens/screen/home_views/timer_view.dart';
import 'package:Bloomee/screens/screen/home_views/setting_views/player_setting.dart';
import 'package:Bloomee/screens/widgets/player_progress_bar.dart';
import 'package:Bloomee/screens/widgets/desktop_player_layout.dart';
import 'package:Bloomee/screens/widgets/artwork_ambient_background.dart';
import 'package:Bloomee/screens/widgets/more_bottom_sheet.dart';
import 'package:Bloomee/screens/widgets/up_next_panel.dart';
import 'package:Bloomee/screens/widgets/volume_slider.dart';
import 'package:Bloomee/screens/widgets/media_metadata_links.dart';
import 'package:Bloomee/screens/screen/player_views/segments_sheet.dart';
import 'package:Bloomee/services/bloomee_player.dart';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:Bloomee/l10n/app_localizations.dart';
import 'package:icons_plus/icons_plus.dart';
import 'package:Bloomee/services/player/player_engine.dart';
import 'package:Bloomee/screens/widgets/like_widget.dart';
import 'package:Bloomee/screens/widgets/play_pause_widget.dart';
import 'package:Bloomee/screens/widgets/snackbar.dart';
import 'package:Bloomee/core/theme/app_theme.dart';
import 'package:Bloomee/utils/load_image.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../blocs/media_player/bloomee_player_cubit.dart';
import '../../blocs/mini_player/mini_player_cubit.dart';
import 'player_views/fullscreen_lyrics_view.dart';

class AudioPlayerView extends StatefulWidget {
  const AudioPlayerView({super.key});

  @override
  State<AudioPlayerView> createState() => _AudioPlayerViewState();
}

class _AudioPlayerViewState extends State<AudioPlayerView> {
  final UpNextPanelController _upNextPanelController = UpNextPanelController();
  bool _desktopQueueOpen = true;
  late final PlayerOverlayCubit _overlayCubit;

  @override
  void initState() {
    super.initState();
    _overlayCubit = context.read<PlayerOverlayCubit>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _overlayCubit.registerUpNextPanelCollapse(
          () => _upNextPanelController.collapse(),
        );
      }
    });
  }

  @override
  void dispose() {
    _overlayCubit.unregisterUpNextPanelCollapse();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final bloomeePlayerCubit = context.read<BloomeePlayerCubit>();
    final musicPlayer = bloomeePlayerCubit.bloomeePlayer;
    final isMobile = MediaQuery.sizeOf(context).width <= 800;

    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned.fill(
          child: StreamBuilder<MediaItem?>(
            stream: musicPlayer.mediaItem,
            initialData: musicPlayer.mediaItem.valueOrNull,
            builder: (context, snapshot) {
              final track = snapshot.data == null
                  ? musicPlayer.currentTrackInfo
                  : mediaItemToTrack(snapshot.data!);
              return ArtworkAmbientBackground(
                imageUrl: track.thumbnail.urlHigh ?? track.thumbnail.url,
                fallbackUrl: track.thumbnail.urlLow ?? track.thumbnail.url,
              );
            },
          ),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          resizeToAvoidBottomInset: false,
          extendBodyBehindAppBar: isMobile,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            foregroundColor: Default_Theme.primaryColor1,
            centerTitle: true,
            leading: IconButton(
              icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
              onPressed: () {
                if (!isMobile || !_upNextPanelController.collapse()) {
                  context.read<PlayerOverlayCubit>().hidePlayer();
                }
              },
            ),
            actions: [
              if (!isMobile)
                IconButton(
                  tooltip: l10n.upNextTitle,
                  onPressed: () =>
                      setState(() => _desktopQueueOpen = !_desktopQueueOpen),
                  icon: const Icon(Icons.queue_music_rounded,
                      size: 22, color: Default_Theme.primaryColor1),
                ),
              IconButton(
                onPressed: () {
                  final mi = musicPlayer.mediaItem.valueOrNull;
                  if (mi != null) {
                    showSegmentsSheet(
                      context,
                      trackId: mi.id,
                      trackDuration: mi.duration ?? Duration.zero,
                      onSeek: (pos) => musicPlayer.seek(pos),
                    );
                  }
                },
                icon: const Icon(MingCute.list_check_3_line,
                    size: 22, color: Default_Theme.primaryColor1),
              ),
              IconButton(
                onPressed: () =>
                    showMoreBottomSheet(context, musicPlayer.currentMedia),
                icon: const Icon(MingCute.more_2_fill,
                    size: 25, color: Default_Theme.primaryColor1),
              )
            ],
            title: Column(
              children: [
                Text(
                  l10n.playerEnjoyingFrom,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Default_Theme.primaryColor1,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ).merge(Default_Theme.secondoryTextStyle),
                ),
                StreamBuilder<String>(
                  stream: musicPlayer.queueTitle,
                  builder: (context, snapshot) {
                    return Text(
                      snapshot.data ?? l10n.playerUnknownQueue,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Default_Theme.primaryColor2,
                        fontSize: 12,
                      ).merge(Default_Theme.secondoryTextStyle),
                    );
                  },
                ),
              ],
            ),
          ),
          body: isMobile
              ? LayoutBuilder(
                  builder: (context, constraints) {
                    return Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        Positioned.fill(
                          child: _PlayerUI(
                            musicPlayer: musicPlayer,
                          ),
                        ),
                        UpNextPanel(
                          peekHeight: 60.0,
                          parentHeight: constraints.maxHeight,
                          controller: _upNextPanelController,
                        ),
                      ],
                    );
                  },
                )
              : SafeArea(
                  top: false,
                  child: Stack(
                    children: [
                      LayoutBuilder(builder: (context, constraints) {
                        final wide = constraints.maxWidth >= 1240;
                        final queueWidth = wide
                            ? 420.0
                            : constraints.maxWidth >= 1100
                                ? 370.0
                                : 320.0;
                        return Padding(
                          padding: EdgeInsets.fromLTRB(
                              wide ? 48 : 28, 8, wide ? 28 : 20, 24),
                          child: Row(
                            children: [
                              Expanded(
                                child: DesktopPlayerLayout(
                                  artwork: const CoverImageVolSlider(),
                                  controls: PlayerCtrlWidgets(
                                      musicPlayer: musicPlayer),
                                ),
                              ),
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 280),
                                curve: Curves.easeInOutCubic,
                                width: _desktopQueueOpen ? (wide ? 36 : 24) : 0,
                              ),
                              ClipRect(
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 280),
                                  curve: Curves.easeInOutCubic,
                                  width: _desktopQueueOpen ? queueWidth : 0,
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Visibility(
                                        visible: _desktopQueueOpen,
                                        maintainState: true,
                                        child: OverflowBox(
                                          alignment: Alignment.centerRight,
                                          minWidth: queueWidth,
                                          maxWidth: queueWidth,
                                          child: UpNextPanel(
                                            peekHeight: 60,
                                            parentHeight:
                                                constraints.maxHeight - 32,
                                            isDesktopMode: true,
                                            onDesktopCollapse: () => setState(
                                                () =>
                                                    _desktopQueueOpen = false),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
        ),
      ],
    );
  }
}

class _PlayerUI extends StatelessWidget {
  final BloomeeMusicPlayer musicPlayer;

  const _PlayerUI({
    required this.musicPlayer,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        SafeArea(
          bottom: false,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              const SizedBox(height: 60),
              const Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                  child: CoverImageVolSlider(),
                ),
              ),
              const SizedBox(height: 15),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: PlayerCtrlWidgets(musicPlayer: musicPlayer),
              ),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ],
    );
  }
}

class CoverImageVolSlider extends StatelessWidget {
  const CoverImageVolSlider({super.key});

  @override
  Widget build(BuildContext context) {
    final bloomeePlayerCubit = context.read<BloomeePlayerCubit>();

    return VolumeDragController(
      child: StreamBuilder<MediaItem?>(
        stream: bloomeePlayerCubit.bloomeePlayer.mediaItem,
        builder: (context, snapshot) {
          final currentTrack =
              bloomeePlayerCubit.bloomeePlayer.currentTrackInfo;
          final highResUrl =
              currentTrack.thumbnail.urlHigh ?? currentTrack.thumbnail.url;
          final lowResUrl =
              currentTrack.thumbnail.urlLow ?? currentTrack.thumbnail.url;

          return SizedBox.expand(
            child: Center(
              child: AspectRatio(
                aspectRatio: 1.0,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: LoadImageCached(
                    imageUrl: highResUrl,
                    fallbackUrl: lowResUrl,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class PlayerCtrlWidgets extends StatelessWidget {
  final BloomeeMusicPlayer musicPlayer;
  const PlayerCtrlWidgets({super.key, required this.musicPlayer});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const _SongInfoRow(),
        const SizedBox(height: 15),
        const PlayerProgressBar(),
        const SizedBox(height: 25),
        ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 450),
          child: _PlayerControlsRow(musicPlayer: musicPlayer),
        ),
      ],
    );
  }
}

class _SongInfoRow extends StatelessWidget {
  const _SongInfoRow();

  @override
  Widget build(BuildContext context) {
    final player = context.read<BloomeePlayerCubit>().bloomeePlayer;
    return Row(
      children: [
        Expanded(
          child: StreamBuilder<MediaItem?>(
            stream: player.mediaItem,
            builder: (context, snapshot) {
              final currentTrack = player.currentTrackInfo;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    currentTrack.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style:
                        Default_Theme.secondoryTextStyle.merge(const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: Default_Theme.primaryColor1,
                    )),
                  ),
                  const SizedBox(height: 4),
                  TrackMetadataLinks(
                    track: currentTrack,
                    showAlbum: currentTrack.album != null,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Default_Theme.secondoryTextStyle.merge(TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: Default_Theme.primaryColor1.withValues(alpha: 0.7),
                    )),
                  ),
                ],
              );
            },
          ),
        ),
        const SizedBox(width: 8),
        const _DownloadButton(),
        const _LikeButton(),
      ],
    );
  }
}

/// FIX M-05: Replaced FutureBuilder (re-queries DB on every stream event) with
/// a StatefulWidget that caches the download state and only re-queries when the
/// media item ID actually changes.
class _DownloadButton extends StatefulWidget {
  const _DownloadButton();

  @override
  State<_DownloadButton> createState() => _DownloadButtonState();
}

class _DownloadButtonState extends State<_DownloadButton> {
  String? _lastTrackId;
  bool _isDownloaded = false;
  StreamSubscription? _mediaSub;

  @override
  void initState() {
    super.initState();
    final player = context.read<BloomeePlayerCubit>().bloomeePlayer;
    _lastTrackId = player.mediaItem.valueOrNull?.id;
    _mediaSub = player.mediaItem.listen((mi) {
      if (mi?.id != _lastTrackId) {
        _lastTrackId = mi?.id;
        _queryDownloadState(mi);
      }
    });
    // Query immediately for the current track.
    _queryDownloadState(player.mediaItem.valueOrNull);
  }

  Future<void> _queryDownloadState(MediaItem? mi) async {
    if (mi == null) {
      if (mounted) setState(() => _isDownloaded = false);
      return;
    }
    try {
      final info = await context
          .read<DownloaderCubit>()
          .getDownloadInfo(mediaItemToTrack(mi));
      if (mounted && _lastTrackId == mi.id) {
        setState(() => _isDownloaded = info != null);
      }
    } catch (_) {
      if (mounted && _lastTrackId == mi.id) {
        setState(() => _isDownloaded = false);
      }
    }
  }

  @override
  void dispose() {
    _mediaSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isDownloaded) return const SizedBox.shrink();
    return Tooltip(
      message: AppLocalizations.of(context)!.tooltipAvailableOffline,
      child: IconButton(
        iconSize: 25,
        icon: Icon(
          Icons.offline_pin_rounded,
          color: Default_Theme.primaryColor1.withValues(alpha: 0.5),
        ),
        onPressed: () {},
      ),
    );
  }
}

/// FIX M-05: Replaced nested FutureBuilder+StreamBuilder+BlocBuilder with a
/// StatefulWidget that caches liked state and only re-queries when track ID changes.
class _LikeButton extends StatefulWidget {
  const _LikeButton();

  @override
  State<_LikeButton> createState() => _LikeButtonState();
}

class _LikeButtonState extends State<_LikeButton> {
  String? _lastTrackId;
  bool _isLiked = false;
  StreamSubscription? _mediaSub;

  @override
  void initState() {
    super.initState();
    final player = context.read<BloomeePlayerCubit>().bloomeePlayer;
    _lastTrackId = player.mediaItem.valueOrNull?.id;
    _mediaSub = player.mediaItem.listen((mi) {
      if (mi?.id != _lastTrackId) {
        _lastTrackId = mi?.id;
        _queryLikedState(mi);
      }
    });
    _queryLikedState(player.mediaItem.valueOrNull);
  }

  Future<void> _queryLikedState(MediaItem? mi) async {
    if (mi == null) {
      if (mounted) setState(() => _isLiked = false);
      return;
    }
    try {
      final liked = await context
          .read<LibraryItemsCubit>()
          .isTrackLiked(mediaItemToTrack(mi));
      if (mounted && _lastTrackId == mi.id) {
        setState(() => _isLiked = liked);
      }
    } catch (_) {
      if (mounted && _lastTrackId == mi.id) {
        setState(() => _isLiked = false);
      }
    }
  }

  @override
  void dispose() {
    _mediaSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final player = context.read<BloomeePlayerCubit>().bloomeePlayer;
    final l10n = AppLocalizations.of(context)!;

    return StreamBuilder<bool>(
      stream: player.engine.playingStream,
      builder: (context, playingSnapshot) {
        final isPlaying = playingSnapshot.data ?? false;
        final currentMedia = player.mediaItem.valueOrNull;
        if (currentMedia == null) return const SizedBox.shrink();

        return LikeBtnWidget(
          isPlaying: isPlaying,
          isLiked: _isLiked,
          iconSize: 25,
          onLiked: () {
            context
                .read<LibraryItemsCubit>()
                .setTrackLiked(mediaItemToTrack(currentMedia), true);
            setState(() => _isLiked = true);
            SnackbarService.showMessage(l10n.playerLiked(currentMedia.title));
          },
          onDisliked: () {
            context
                .read<LibraryItemsCubit>()
                .setTrackLiked(mediaItemToTrack(currentMedia), false);
            setState(() => _isLiked = false);
            SnackbarService.showMessage(l10n.playerUnliked(currentMedia.title));
          },
        );
      },
    );
  }
}

class _PlayerControlsRow extends StatelessWidget {
  final BloomeeMusicPlayer musicPlayer;
  const _PlayerControlsRow({required this.musicPlayer});

  Widget _buildControlColumn({required Widget top, required Widget bottom}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(height: 70, alignment: Alignment.center, child: top),
        SizedBox(height: 40, child: bottom),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildControlColumn(
          top: IconButton(
            icon: const Icon(MingCute.alarm_1_line,
                color: Default_Theme.primaryColor1, size: 28),
            onPressed: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const TimerView())),
          ),
          bottom: const _LoopControl(),
        ),
        _buildControlColumn(
          top: IconButton(
            icon: const Icon(MingCute.skip_previous_fill,
                color: Default_Theme.primaryColor1, size: 35),
            onPressed: musicPlayer.skipToPrevious,
          ),
          bottom: IconButton(
            icon: const Icon(MingCute.align_center_line,
                color: Default_Theme.primaryColor1, size: 24),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => const FullscreenLyricsView(),
              ));
            },
          ),
        ),
        _buildControlColumn(
          top: const _PlayPauseButton(),
          bottom: const SizedBox(height: 40),
        ),
        _buildControlColumn(
          top: IconButton(
            icon: const Icon(MingCute.skip_forward_fill,
                color: Default_Theme.primaryColor1, size: 35),
            onPressed: musicPlayer.skipToNext,
          ),
          bottom: IconButton(
            icon: const Icon(MingCute.settings_6_line,
                color: Default_Theme.primaryColor1, size: 24),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PlayerSettings())),
          ),
        ),
        _buildControlColumn(
          top: const _ShuffleControl(),
          bottom: const _ExternalLinkControl(),
        ),
      ],
    );
  }
}

class _LoopControl extends StatelessWidget {
  const _LoopControl();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<LoopMode>(
      stream: context.read<BloomeePlayerCubit>().bloomeePlayer.loopMode,
      builder: (context, snapshot) {
        final loopMode = snapshot.data ?? LoopMode.off;
        final l10n = AppLocalizations.of(context)!;
        return PopupMenuButton(
          itemBuilder: (_) => [
            PopupMenuItem(value: 0, child: Text(l10n.playerLoopOff)),
            PopupMenuItem(value: 1, child: Text(l10n.playerLoopOne)),
            PopupMenuItem(value: 2, child: Text(l10n.playerLoopAll)),
          ],
          child: Icon(
            loopMode == LoopMode.off
                ? MingCute.repeat_line
                : loopMode == LoopMode.one
                    ? MingCute.repeat_one_line
                    : MingCute.repeat_fill,
            color: loopMode == LoopMode.off
                ? Default_Theme.primaryColor1
                : Default_Theme.accentColor1,
            size: 24,
          ),
          onSelected: (value) {
            final player = context.read<BloomeePlayerCubit>().bloomeePlayer;
            if (value == 0) player.setLoopMode(LoopMode.off);
            if (value == 1) player.setLoopMode(LoopMode.one);
            if (value == 2) player.setLoopMode(LoopMode.all);
          },
        );
      },
    );
  }
}

class _ShuffleControl extends StatelessWidget {
  const _ShuffleControl();

  @override
  Widget build(BuildContext context) {
    final player = context.read<BloomeePlayerCubit>().bloomeePlayer;
    return StreamBuilder<bool>(
      stream: player.shuffleMode,
      builder: (context, snapshot) {
        final isShuffle = snapshot.data ?? false;
        return IconButton(
          icon: Icon(
            MingCute.shuffle_2_fill,
            color: isShuffle
                ? Default_Theme.accentColor1
                : Default_Theme.primaryColor1,
            size: 28,
          ),
          onPressed: () => player.shuffle(!isShuffle),
        );
      },
    );
  }
}

class _ExternalLinkControl extends StatelessWidget {
  const _ExternalLinkControl();

  @override
  Widget build(BuildContext context) {
    final player = context.read<BloomeePlayerCubit>().bloomeePlayer;
    return IconButton(
      icon: const Icon(MingCute.external_link_line,
          color: Default_Theme.primaryColor1, size: 24),
      onPressed: () async {
        final url = player.currentTrackInfo.url;
        if (url != null) {
          await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
        } else {
          SnackbarService.showMessage(
              AppLocalizations.of(context)!.snackbarCouldNotOpenLink);
        }
      },
    );
  }
}

class _PlayPauseButton extends StatelessWidget {
  const _PlayPauseButton();

  @override
  Widget build(BuildContext context) {
    final musicPlayer = context.read<BloomeePlayerCubit>().bloomeePlayer;
    return BlocBuilder<MiniPlayerCubit, MiniPlayerState>(
      builder: (context, state) {
        Widget child;
        Color buttonColor = Default_Theme.accentColor2;

        if (state.isLoading || state.isResolving) {
          child = const CircularProgressIndicator(
              strokeWidth: 3, color: Default_Theme.primaryColor1);
          buttonColor = state.isPlaying
              ? Default_Theme.accentColor1
              : Default_Theme.accentColor2;
        } else if (state.isCompleted) {
          child = const Icon(FontAwesome.rotate_right_solid,
              color: Default_Theme.primaryColor1, size: 32);
          buttonColor = Default_Theme.accentColor1;
        } else if (state.hasError) {
          child = const Icon(MingCute.warning_line,
              color: Default_Theme.primaryColor1, size: 32);
        } else if (state.isVisible) {
          return PlayPauseButton(
            size: 70,
            onPause: musicPlayer.pause,
            onPlay: musicPlayer.play,
            isPlaying: state.isPlaying,
          );
        } else {
          child = const SizedBox();
        }

        return GestureDetector(
          onTap: () {
            if (state.isCompleted) {
              musicPlayer.seek(Duration.zero);
              musicPlayer.play();
            } else if (state.hasError) {
              musicPlayer.play();
            }
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutCubic,
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: buttonColor,
              boxShadow: [
                BoxShadow(color: buttonColor, spreadRadius: 1, blurRadius: 15)
              ],
            ),
            child: Center(child: SizedBox(width: 32, height: 32, child: child)),
          ),
        );
      },
    );
  }
}
