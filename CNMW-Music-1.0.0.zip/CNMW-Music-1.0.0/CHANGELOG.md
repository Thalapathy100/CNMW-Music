## [3.1.1] - 2026-11-23

### Added
- **Custom Desktop Title Bar**: A new title bar with round minimize, maximize, and close buttons looks the same on Windows, Linux, and macOS, while keeping native snapping, resizing, window animations, and the taskbar.
- **Close Button Options**: Choose whether closing the window keeps music playing in the system tray (menu bar on macOS), minimizes the window, or quits Bloomee, in Settings > Window & Tray.
- **System Tray Controls**: The tray icon shows the current song and offers Play/Pause, Next, Previous, Show/Hide, and Quit. On Windows, clicking it brings Bloomee back.
- **Microsoft Store Package**: Bloomee can now be packaged for the Microsoft Store. Store installs are updated by the Store and skip the in-app update check.
- **Last.fm Scrobble Queue**: Scrobbles are saved while offline and sent automatically later, with sync status, a pending count, Sync Now, and Clear Queue in Last.fm settings.
- **Windows Media Controls**: The Windows media overlay now shows the song's position and cover art and can seek.
- **News & Announcements**: The bell on Home now shows news, our other apps, sign-up links, and important notices published on the Bloomee website, plus any available update. New entries are marked, can be dismissed, and work offline. One small card can appear on Home; turn it off in Settings > Updates & news.

### Changed
- **Home Page**: Faster and smoother with the same look. Sections load only as you scroll to them, artwork is decoded at the size shown, and loading placeholders keep the page from jumping.
- **Discord Rich Presence**: Rebuilt on a dedicated background connection with live connection status, your Discord account, a presence preview, and options for artwork, progress, links, local files, and paused behavior.
- **Up Next on Desktop**: The queue panel takes a soft glow from the current artwork. Queue rows show actions only on hover, use one subtle hover highlight, and lift neutrally while dragging.
- **Queue Reordering**: Moving or removing songs no longer reloads every row and its artwork. On mobile, long-press a song to drag it or swipe it away to remove it.
- **Library Reordering**: Reorder mode now shows a short hint, a Done button, and neutral drag handles. Back or Escape exits it, and pinned playlists stay grouped.
- **Playlist Play Button**: Playing a playlist that is already queued resumes it instead of restarting it, and adding a whole playlist to the queue skips songs already queued.
- **Navigation Layout**: Phones always use the bottom navigation bar, tablets use the side rail, and desktop windows switch by width.
- **Search and Sheets**: Faster search, lyrics search, and option sheets with less rendering work.
- **Window Name**: The window and Start menu now show Bloomee🌸.
- **Update Checks**: Bloomee checks for updates once per launch instead of up to three times, and the update dialog appears once per new version instead of on every launch.
- **Plugin Requests**: Home sections, search, charts and suggestions load faster. All plugins and downloads now share one compressed network connection pool, and Bloomee runs on fewer background threads.
- **Track Matching**: Matching songs across plugins for charts, imports and replacements now runs in native code, about five times faster, with the same results.

### Fixed
- Fixed the full player's progress bar freezing at the start of a song after opening the player.
- Fixed the chart carousel slowing down or freezing Home at startup. It starts sliding a few seconds after Home appears and pauses while you touch it, while Home is covered or scrolled away, and while Bloomee is minimized or in the tray. On desktop, arrows appear when you hover over it.
- Fixed songs being skipped silently when their stream stopped early.
- Fixed playback errors from a preloaded song being blamed on the wrong track.
- Fixed queue changes made in quick succession sometimes not being saved.
- Opening Bloomee again while it is running, including from the tray, now brings the existing window back instead of starting a second copy.
- Tray and window menus on Windows now use the dark theme.
- Notifications are no longer deleted when you leave the notifications screen.
- The "Update alerts" switch now shows its real state; it appeared off while alerts were on.

### Developer Notes
- Added window_manager 0.5.2, tray_manager 0.5.3, and msix. Linux builds now need libayatana-appindicator3-dev.
- Release builds also produce an unsigned Microsoft Store MSIX as a separate artifact.
- Added tests for the desktop title bar, close options, scrobble queue, and playback session tracking.
- Rust: one shared async `reqwest` client (gzip, zstd) replaces six blocking clients; the bridge runs on a custom handler with 2 to 4 workers and at most 16 blocking threads; downloads are async. Removed the unused `host_funcs` module.
- Track matching moved to `rust/src/api/matching.rs`; `fuzzywuzzy` and the unused `string_similarity` were removed. `test/track_matching_test.dart` checks it against the previous Dart scores (`rust/tests/fixtures/match_scores.json`) when the native library is built.
- Plugin benchmark: `cargo test --release --lib bench -- --ignored --nocapture --test-threads 1` in rust/.
- Announcements are published from the git-ignored `ghpage/feed.json` straight to the `ghpage` branch by `deploy_page.py --feed`, which rejects an invalid feed. See docs/announcements.md. Preview with `flutter run --dart-define=BLOOMEE_FEED=ghpage/feed.json`, or render `test/feed_preview_test.dart` to PNG.

## [3.1.0+207] - 2026-10-21

### Added
- **New Languages**: Added Turkish, Portuguese, and French translations.
- **Portable JSON Backups**: Save and share playlists, likes, saved collections, playback and search histories, and portable preferences.
- **Import Preview and Options**: Preview backup contents before importing as new playlists, merging with existing data, or replacing selected sections. Older JSON backups can be imported as new playlists or merged.
- **Library Recovery**: Recover missing playlists and download records from retained v3 databases and recovery copies through Storage settings or the empty Offline tab.
- **Recovery Copies**: Browse private recovery snapshots, with automatic daily checks and protection copies before imports and database resets.
- **Android Download Folder Selection**: Choose a download folder through the system picker with persistent access permissions.

### Changed
- **Translations**: Completed existing translations, refined Spanish wording, and improved terminology and message context across languages.
- **Localization Cleanup**: Removed 90 unused translation entries.
- **Player Redesign**: Improved desktop space usage with larger artwork and a collapsible queue, and unified ambient artwork backgrounds across desktop, mobile, and lyrics views.
- **Lyrics Experience**: Refined fullscreen lyrics, scrolling, timing adjustments, and shared playback progress styling.
- **Backup File Handling**: Unified file import previews across Settings, Library, Android Open With and Share, and desktop file arguments.
- **Content Imports**: Allow more time to fetch collection details and tracks, and retry the failed step while reusing requests already in progress.
- **Playback Efficiency**: Reduced background network traffic by bounding audio buffering and removing bulk chart prefetching, and reduced player transition jank and unnecessary rendering.
- **About and Release Notes**: Refined the warm gradient styling, reduced animation rebuilds, and loaded release-note entries on demand for more responsive pages after updates and first launch.
- **Mobile Up Next**: Reduced rendering work when opening, closing, and scrolling the queue, including long queues, while preserving the panel's visual depth.
- **Discord Rich Presence**: Improved per-track artwork, album information, playback timing, and play/pause indicators.
- **Cancelable Database Resets**: Schedule database resets for the next startup and cancel them before restarting.

### Fixed
- Fixed About page overflow on small screens and respected reduced-motion preferences for its background animations.
- Prevented repeated version loading and changelog settings writes during page rebuilds.
- Preserved duplicate songs in Up Next and corrected their playback, removal, and reorder indices.
- Fixed the blank Portuguese language selection and mapped older regional preferences to the single Português option.
- Corrected text encoding, plural counts, and missing song and plugin names in translated messages.
- Fixed overflowing navigation labels on small screens and improved wrapping for longer translated controls.
- Ensured setup screens and keyboard shortcut messages follow the selected language, and clarified backup import explanations.
- Preserved download records and playlist membership when audio files are temporarily missing or inaccessible, with improved recovery of relocated files.
- Improved playback interruption recovery and refreshed rejected stream URLs when servers return HTTP 401, 403, or 410.
- Fixed local music scanning on Android 8.1 and improved playback, deletion, and recovery of files accessed through Android document URIs.
- Improved plugin setup verification and restored providers after failed plugin updates.
- Fixed lyrics timestamp parsing, scrolling edge cases, cache failure handling, and requests completing after the lyrics view closes.
- Prevented outdated content import results from affecting a new or canceled import.
- Fixed Android build compatibility and icon dependency issues.
- Show a clear startup error when initialization fails while preserving existing database files.
- Clear saved queue state when the queue becomes empty and protect queued tracks from metadata cleanup.
- Prevent older playlist loads from replacing the currently selected playlist and reuse pending page requests during Play All.
- Let active desktop screens handle Escape and Backspace before closing the player.
- Retry saving completed downloads to the library without downloading the files again.

### Upgrade Notes
- Removed automatic migration of pre-v3 databases. Library recovery supports retained v3 databases and recovery snapshots; it does not import pre-v3 databases.

### Developer Notes
- Added regression tests for translation coverage, placeholders, text encoding, language switching, and translated layouts.
- Upgraded Isar from a prerelease to stable 3.4.1 and updated compatible dependencies.
- Run release builds in parallel, move Android release builds to Linux, cache dependencies and native build outputs, and publish release artifacts together.
- Pin Windows release builds to Visual Studio 2022 for native plugin compatibility.
- Expanded automated test coverage and configured Linux tests to find the Isar native library in worker isolates.

## [3.0.4] - 2026-05-29

### Fixed
- Fixed plugin auto updated and few other bugs.

## [3.0.3] - 2026-05-16

### Fixed
- Fixed playlist tap misalignment by remapping track index
- Fixed linear stacking of repeated listned songs.
- Fixed shared url resolver early stage
- search suggestion enhancements
- stabilize playback startup and plugin.
- some localizations completion


## [3.0.1] - 2026-03-24

### Fixed
- Fixed equalizer range to around - 15db.
- Fixed linear stacking of repeated listned songs.
- Fixed Some migration related problems.
- Fixed only 40 songs persisted after a reordering applied to the playlist.


## [3.0.0] - 2026-03-18

### Added
- **Local Music Support Available Now**: Introduced the local music playing in the device.
- **New Plugin Runtime [bex]**: Introduced a Rust-backed plugin system built with waclay + wasmi, loading, unloading, execution, and updates.
- **Lyrics Viewer + Lyrics Offset**: You can now offset lyrics if lyrics are not syncing up.
- **Equalizer support now available**: Equalizer support is now available for all devices😊.
- **Languages support is expanding**: Strings are localized so soon you will have bloomee in your own languages.
- **Karaoke style Lyrics**: Bydefault we will now have karaoke style lyrics player.
- **Playlist ordering and pinning**: Playlists in library can now be pinned or reordered as user wants.
- **Crossfade support**: Crossfade is now supported for all device.
- **Smart Replace**: Sometimes some remote song may get dead to revive them using differnt song and replace in your playlist this feature will help you to replace the songs inside your playlist with working tracks.
- **Refresh Metadata**: Can now refresh the old metadata if the track metadata is fuzzy.
- **Plugin Types**:
    - `contentResolver`: search, details, media resolution, home/discover sections.
    - `chartProvider`: chart listings and chart detail feeds.
    - `lyricsProvider`: synced and plain lyrics providers.
    - `searchSuggestionProvider`: query suggestions/autocomplete.
    - `contentImporter`: plugin-driven import flows for external collections.
- **Plugin Repository Bootstrap**: Added hosted repository bootstrap, one-time setup flow, repository syncing, and install-on-bootstrap logic.
- **Plugin Auto-Update Pipeline**: Added background repository sync with semantic version comparison and automatic plugin updates.
- **Country-Aware Plugin Distribution**: Added `country_allowlist` support in repository manifests and packed plugin install validation.
- **Country Detection Service**: Added normalized country detection with caching and fallback strategy for first-run reliability.
- **Plugin Response Caching**: Added in-memory + persisted cache flow for plugin data (discover/charts/details).
- **Plugin Priority Controls**: Added resolver/lyrics priority settings and plugin default auto-selection.
- **Richer Plugin Commands**: Expanded plugin command surface (track/album/artist/playlist details, suggestions, lyrics, segments, import operations, collection metadata).
- **Plugin Importer Improvements**: Refactored importer flow to integrate plugin-backed source parsing and internal collection mapping.
- **Cross-Plugin Resolution**: Added fallback and replacement logic for unavailable tracks and dead source links.
- **Smart Playback Recovery**: Added stronger recovery and fallback paths for interrupted/failed streaming operations.
- **Local + Remote Unified Playback**: Added improved local content pathing and plugin-backed remote resolution coexistence.
- **Keyboard Shortcut Enhancements**: Added desktop-focused shortcut improvements and shortcut feedback indicator improvements.
- **UI/UX Refreshes**:
    - Redesigned mini-player and player settings surfaces.
    - Enhanced chart, search, and playlist browsing experiences.
    - Improved context actions and visual transitions.
- **Localization Expansion**: Added/updated large batches of localized strings for plugin and setup workflows.

### Changed
- **Architecture Migration (v3 line)**: Shifted from tightly coupled source integrations to a plugin-first modular architecture.
- **Data/Storage Refactors**: Large refactor across repository/DAO/state boundaries to support plugin-native IDs and content abstractions.
- **Downloader Evolution**: Moved major parts of downloading workflow toward Rust-backed internals and improved tracking pipeline.
- **Player Engine Stability**: Refactored queue, transitions, crossfade flow, and error handling to reduce edge-case dead states.
- **Settings Defaults & Normalization**:
    - Crossfade default aligned to `2s` across UI + runtime restore paths.
    - Streaming quality default aligned to `High` across settings + resolver usage.
    - Country default standardized to `US` with one-time normalization and persistence.
- **Bootstrap Reliability**: Removed fragile reachability gate that could produce false "offline" setup failures.
- **Manifest Compatibility**: Improved manifest-version parsing and compatibility handling in update checks.
- **Theme/Style Modernization**: Completed broad `withOpacity` migration to `withValues` and related visual consistency cleanups.

### Fixed
- Fixed plugin setup stalls around early bootstrap progress caused by strict network/country resolution paths.
- Fixed auto-update gating that skipped valid plugin updates under older manifest value formats.
- Fixed defaults mismatch where settings UI values could differ from runtime player behavior until manual toggle.
- Fixed crossfade runtime restore fallback inconsistency that could disable crossfade on first launch.
- Fixed stream quality fallback inconsistency causing startup playback to prefer lower quality than settings state.
- Fixed multiple queue/player edge cases: skip/advance races, dead loading states, and stale resolver transitions.
- Fixed repository/bootstrap failure handling and improved retry resilience for plugin setup/update flows.
- Fixed numerous UI state sync issues in search, playlist, and details surfaces.

### Developer Notes
- Legacy source-specific identifiers are retained only where required for migration compatibility and old data mapping.
- The recommended integration path is now fully plugin-based through repository manifests and `.bex` package installation.

## [2.13.3] - 2025-12-01

### Added
- **Shortcut Pressed Indicator for Desktop**: Added visual indicator for pressed keyboard shortcuts on desktop platforms.
- **New Flavor Dev[Android]**: Introduced a new development flavor for Android builds.

### Fixed
- **What's New Font Family**: Fixed font family issues in the "What's New" section.
- **Keyboard Shortcut**: Resolved issues with keyboard shortcuts functionality.
- **Add to Playlist**: Fixed bugs in the add to playlist feature.
- **Player Disposer Problem**: Addressed player disposer issues on Realme, Oppo, and similar devices.

## [2.13.2] - 2025-11-30

### Added
- **Library Item Search Box**: Added search functionality for library items to improve navigation and discovery.
- **New Search in Playlist Database Function**: Implemented enhanced search capabilities within playlist databases.
- **DNS Checker**: Added DNS connectivity checking feature for better network diagnostics.
- **Touch Device Support**: Improved support for touch-based interactions across the application.
- **Redesigned Up Next Panel**: Completely redesigned the "Up Next" panel with modern UI elements.
- **Full Screen Lyrics Viewer**: Introduced a new full-screen lyrics viewing mode with enhanced display options.
- **Auto Scroll in Queue**: Automatic scroll to every song changed in the queue.

### Changed
- **New Progress Bar for Player**: Implemented a new progress bar design for the media player.
- **Up Next Panel and Song Tile Improvements**: Enhanced the "Up Next" panel and song tiles for better usability and appearance.
- **Ambient Background Enhancement**: Improved ambient background effects throughout the application.
- **Song Info UI Updates**: Updated the song information display interface for better readability.
- **Add to Playlist UI**: Redesigned the "Add to Playlist" feature with circular stacked avatars and improved layout.
- **Player Enhancements**: Various improvements to the media player functionality and user experience.
- **Custom Animated List**: Implemented custom animated lists for smoother UI transitions.
- **Subtitle Override in Song Model**: Added ability to override subtitles in song metadata.
- **Fullscreen Up Next Panel**: Made the fullscreen "Up Next" panel translucent for better visual integration.
- **Lyric Widget Enhancements**: Improved colors and icons in the lyrics widget.
- **Player UI Optimizations**: Optimized player interface for better performance and usability.
- **Gradient Adjustments**: Fine-tuned gradient effects in the player interface.
- **Media Kit Integration**: Switched to MediaKit for Android platform for improved media handling.

### Fixed
- **Font Fixes**: Resolved font rendering issues across the application.
- **Mini Player Fixes**: Fixed bleed and progress bar issues in the mini player.
- **Warning Fixes**: Addressed various deprecation warnings, including `.withOpacity` usage.
- **Full Screen Lyric View**: Corrected display issues in full-screen lyrics mode.
- **Auto Wake Controls**: Fixed auto-scroll behavior in wake controls.
- **Up Next Panel**: Resolved various issues with the "Up Next" panel functionality.
- **Desktop Handle Fix**: Fixed panel handle behavior on desktop platforms.
- **Player Reconfiguration**: Corrected player reconfiguration issues on Android.
- **JSON File Opening**: Partially addressed issues with JSON file handling (ongoing).

## [2.12.5] - 2025-10-25
- **Flutter Version Upgrade**: Updated Flutter version to 3.35.4 with CI/CD pipeline improvements.
- **Package Upgrades**: Updated various dependencies and packages for better performance and security.
- **Connectivity Improvements**: Enhanced connectivity handling after package upgrades.
- **provider source Shared Music**: Added support for playing provider source shared music links.
- **Audio Source Optimization**: Removed concatenating audio source usage for improved performance.
- **Network Failure Handling**: Added maximum limit of 10 retries before shifting to next song on network failures.
- **Track Recovery**: Improved track recovery when lost during network interruptions.
- **About Page Refactor**: Refactored the about section for better maintainability.
- **Color Analyzer**: Added new color analyzer functionality from URLs.
- **Chart Widget Fixes**: Fixed image display issues in chart widgets.
- **Billboard Image Fixes**: Resolved image loading issues in Billboard charts.

### Fixed
- **Isar Version Compatibility**: Fixed Isar database version compatibility issues.
- **Code Reverts**: Reverted problematic code changes to maintain stability.

## [2.12.4] - 2025-09-28

### Added
- **Bulk Download Feature**: Added the ability to select and download multiple songs from playlists at once.
- **Enhanced Queue Management**: Added `showPlayNext` and `showAddtoQueue` boolean controls for better UI customization.
- **Song Options in Up Next Panel**: Added song options menu in the "Up Next" panel for better track management.
- **Recently Played Tracking**: Implemented recently played tracking with configurable thresholds (40% playback or 15 seconds).
- **Trendshift Badge**: Added Trendshift badge to the project.

### Changed
- **Audio Service Updates**: Updated audio service configuration and handling.
- **Bulk Download UI Enhancements**: Improved the bulk download progress dialog and user experience.
- **Queue Title Broadcasting**: Fixed queue title override to properly broadcast updated queue titles.
- **Button Renaming**: Changed "Play Now" button to "Play with Mix" for clarity.
- **Player Error Handling**: Enhanced error handling for network-related playback issues.
- **Snackbar Improvements**: Enhanced snackbar notifications throughout the app.
- **Volume Control**: Fixed volume sliding on cover art for manual control.
- **provider source Download Fix**: Temporary fix for provider source downloading (requires future maintenance for legacy extractor package).
- **Restore Warning**: Clarified warning messages for restore operations.
- **Code Cleanup**: General code cleanup and optimizations.
- **Documentation Updates**: Updated README, GitHub Pages, and fastlane changelog.
- **Workflow Improvements**: Enhanced GitHub Actions workflows for better CI/CD.
- **Funding Information**: Updated funding URLs and configuration.

### Fixed
- **Bulk Download Snackbars**: Fixed snackbar notifications to show only one message for bulk downloads instead of individual messages per song.

## [2.12.3] - 2025-08-17

### Added
- **Windows Media Controls**: Implemented native media controls for Windows for a better desktop experience with `audio_service_win`.
- **Search in Downloads**: Added search functionality to the offline/downloads screen.
- **Changelog**: Added `CHANGELOG.md` for release notes and version history.
- **Changelog viewer**: In-app viewer that shows "what's new" after updates so users see release notes on first run after an update.
- **Global event notifier**: New global event cubit used for app-wide notifications and to drive the updated updater popup logic.
 - **Android: Backup sharing**: Added Android-specific sharing for backup JSON files so users can easily export/share backups from the app.

### Changed
- **Downloader Overhaul**: The download manager has been completely rewritten from the ground up, removing the `flutter_downloader` dependency. This new implementation enables downloads on desktop platforms and shows live progress on the downloads screen.
- **Backup & Restore Rework**: The backup and restore functionality has been completely rewritten to use a more reliable JSON format.
- **UI/UX Enhancements**:
    - Updated the app logo and various icons.
    - Improved themes and color schemes.
    - Redesigned and updated the "About" page to include the build number and small layout/text refinements.
    - Enhanced the Android notification thumbnail to a medium quality for better visuals.
- **Library Management**: Implemented a playlist watcher to keep the library in sync.
- **Player Modularization**: Refactored the core audio player code for better state management and maintainability.
- **Dependencies**: Upgraded Flutter, `flutter_bloc`, and the Android Gradle Plugin to their latest versions.
- **App updater**: Updated popup logic to use the new global event cubit and applied several updater fixes.
- **CI / Workflow**: Automatic version reading from `package.json` is enabled; Linux build number offset adjusted (+121) to align with Windows/Android.
- **Deploy script**: The deploy script now copies the changelog into the GitHub Pages build directory before force-pushes.
- **Docs & README**: Small README and documentation updates.
 - **Global footer animation**: Page animation in the global footer changed to a soft zoom-in transition for smoother navigation.
 - **provider source service improvements**: Enhanced the provider source service/provider for better reliability and performance (provider enhancements and multiple bug fixes).

### Fixed
- Resolved a bug with the 'like' button on album views.
- Fixed an issue preventing clicks on media items in the "Recently Played" section.
- Addressed loading problems on provider music source artist pages.
- Corrected the app updater logic and fixed a SourceForge header issue affecting Android updater requests.
- Fixed various UI bugs, including carousel alignment and button states.
 - Fixed play/pause not responding on first-time button press.
 - Fixed several UI issues: contrast adjustments, gradient box rendering, button state fixes, and small About-page fixes including back-pop navigation behavior.
 - Corrected Liberapay naming.

### Removed
- Removed the `flutter_downloader` package.
- Removed the `legacy stream adapter` script.

## [2.11.6] - 2025-05-05

### Changed
- Refactored import/export functionality.
- General code cleanups and optimizations.

### Fixed
- Resolved issues with provider source streaming.
- Addressed bugs related to provider source playlists.

## [2.11.5] - 2025-03-17

### Changed
- Updated provider source client and carousel functionality.
- Upgraded libraries and packages.

## [2.11.4] - 2025-03-16

### Changed
- Enhanced the "check related item" feature.
- User interface improvements for playlist and artist views.

### Fixed
- Addressed a bug in the provider music source API.
- Fixed an issue with the provider source audio stream.

## [2.11.3] - 2025-03-08

### Added
- **Discord Rich Presence**: Show your current listening activity on Discord.

### Changed
- Updated Billboard charts integration.

### Removed
- Discontinued support for TikTok Top 50 chart from Billboard.

### Fixed
- Resolved issues with Discord Rich Presence integration.

## [2.11.2] - 2025-02-27

### Changed
- Redefined search suggestions for better accuracy.
- Upgraded the BLoC library.

### Fixed
- Corrected a bug in the `putSearchHistory` function.
- Fixed a bug related to spaces in search queries.

## [2.11.1] - 2025-02-25

### Added
- Implemented a setting for enabling/disabling autoplay.

### Fixed
- Resolved a bug preventing adding tracks to the queue.
- Fixed an issue with shuffle functionality in playlists.
- Corrected an app updater issue for ABI `versionCode`.

## [2.11.0] - 2025-02-24

### Added
- Implemented `provider audio source` for improved provider source audio handling.
- Added new queue management functions.

### Changed
- Refactored the "Up Next" panel and player for better performance.
- Shifted to `media_kit` for Windows audio playback.

### Fixed
- Addressed bugs in the mini-player and "Up Next" animations.
- Re-enabled cleartext traffic for provider source streams to resolve playback issues.

## [2.10.16] - 2025-02-17

### Changed
- Updated the `legacy extractor package` package.

## [2.10.15] - 2025-02-05

### Fixed
- Corrected formatting issues on the provider music source home screen.

## [2.10.14] - 2025-01-24

### Fixed
- Addressed a bug causing provider source stream failures.

## [2.10.13] - 2025-01-16

### Changed
- Improved error handling to stop playback on player exceptions.
- Added a development "flavor" for better testing.

### Fixed
- Resolved a mini-player issue where it would show infinite loading on playback failure.

## [2.10.11] - 2024-12-26

### Changed
- Switched to `legacy stream adapter` for handling provider source streams.
- Improved caching mechanisms.

## [2.10.10] - 2024-12-23

### Changed
- Updated the provider source API implementation.
- Refactored provider source background link refreshing to run in a separate isolate for better performance.

## [2.10.9] - 2024-11-09

### Added
- Implemented an option to manually save lyrics.
- Added a settings option to auto-save lyrics.

### Changed
- Enhanced the lyrics search dialog.

## [2.10.8] - 2024-10-16

### Added
- Implemented mouse scrolling support for the volume bar on desktop.

### Changed
- Decreased the volume increment/decrement speed for finer control.

## [2.10.7] - 2024-10-11

### Fixed
- Addressed various bugs in the legacy source adapter API integration.

## [2.10.6] - 2024-10-09

### Added
- Implemented swipe gestures (next/previous) on the mini-player.

### Changed
- Upgraded the `legacy extractor package` package.

## [2.10.5] - 2024-10-05

### Added
- Introduced a "Last.fm Picks" widget on the home screen.
- Implemented Last.fm authentication.

### Changed
- Enhanced the app updater functionality.

## [2.10.1] - 2024-10-04

### Added
- **Last.fm Scrobbling**: Automatically scrobble your played tracks to Last.fm, with offline caching for network failures.

### Changed
- Enabled seek controls in Android notifications.

## [2.9.13] - 2024-09-25

### Fixed
- Addressed a bug with provider source links.
- Updated `legacy extractor package` to fix a critical bug.

## [2.9.12] - 2024-09-22

### Changed
- Ensured the same `versionCode` is used for all ABIs in APK builds.
- Added tooltips for better user experience.

### Fixed
- Disabled the download button on platforms other than Android.

## [2.9.11] - 2024-09-11

### Changed
- Moved the "get related songs" API call to a compute function to prevent UI blocking.

### Fixed
- Addressed a bug preventing songs from being added to playlists.

## [2.9.10] - 2024-09-11

### Changed
- Migrated the Isar database to a community fork (`isar_community`).

## [2.9.9] - 2024-09-03

### Fixed
- Addressed a database restoration issue for versions prior to 2.9.8.

## [2.9.8] - 2024-09-02

### Added
- Implemented a SourceForge version checker for app updates.
- **Save Online Media**: Added the ability to save online playlists, artists, and albums to your library.

### Changed
- Migrated the database path from `appDocumentPath` to `appSupportPath`.

## [2.9.6] - 2024-08-29

### Added
- Support for searching and viewing provider music source artists, albums, and playlists.
- Added a "more options" menu to song cards.

### Fixed
- Resolved bugs in the chart and artist views.

## [2.9.5] - 2024-08-16

### Changed
- Updated workflows to build split APKs per ABI for smaller app sizes.
- Improved image formatting and loading across the app.

### Fixed
- Addressed a bug in playlist editing.

## [2.9.3] - 2024-08-11

### Changed
- Migrated Flutter version from 3.19.x to 3.24.0.
- Improved the library screen UI and mini-player blur effect.
- Updated the playlist screen to use `SliverReorderableList` for a smoother experience.

## [2.9.2] - 2024-08-08

### Added
- Introduced a "view info" feature for playlists.
- Added a playing indicator to playlist tiles.

### Changed
- UI enhancements for the "like" button and player screen.

## [2.9.1] - 2024-08-06

### Added
- Implemented a settings option to select and manage external charts.
- **provider music source Importer**: Added the ability to import single tracks, albums, and playlists from provider music source.

## [2.8.3] - 2024-08-02

### Added
- **Lyrics**: Implemented a lyrics feature to view song lyrics within the app.
- **Linux Support**: Added experimental support for Linux using `media_kit` bindings.

## [2.8.2] - 2024-07-21

### Changed
- The update source has been shifted from GitHub to SourceForge.
- UI improvements for cover art and chart widgets.

### Fixed
- Resolved an issue with offline song downloads on Android 13 and 14.

## [2.8.0] - 2024-07-06

### Added
- **Windows Support**: Enabled official support for Windows desktop.

### Changed
- Made the player and navigation bar responsive for different screen sizes.

## [2.7.13] - 2024-05-14

### Fixed
- Addressed an issue where the mixed API search returned no results.

## [2.7.10] - 2024-04-26

### Added
- Implemented country-based music recommendations on the home page.
- Added a refresh indicator to the home page.

### Changed
- Implemented a volume slider.

## [2.7.7] - 2024-04-24

### Added
- Implemented a song information screen.

## [2.7.6] - 2024-04-21

### Added
- Implemented an "Up Next" sliding panel in the player screen.

## [2.7.5] - 2024-04-16

### Added
- Implemented shuffle and repeat modes.

## [2.7.2] - 2024-04-14

### Changed
- Re-implemented the mini-player using BLoC to fix bugs.

### Fixed
- Implemented a check for app updates and provided notifications.

## [2.7.0] - 2024-04-12

### Added
- **provider source Home**: Integrated the provider music source homepage into the "Explore" tab.
