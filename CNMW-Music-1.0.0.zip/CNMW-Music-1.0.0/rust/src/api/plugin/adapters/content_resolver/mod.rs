pub mod bindgen;

use crate::api::plugin::commands::{
    ContentResolverCommand, ContentSearchFilter, PluginResponse,
};
use crate::api::plugin::errors::{PluginError, PluginResult};
use crate::api::plugin::loader::get_instance_with_host;
use crate::api::plugin::models::{
    AlbumDetails, AlbumSummary, ArtistDetails, ArtistSummary, Artwork, CardType, ChartItem,
    ChartSummary, ImageLayout, Lyrics, MediaItem, PagedAlbums, PagedMediaItems, PagedTracks,
    PlaylistDetails, PlaylistSummary, Quality, Section, StreamSource, Track,
};
use crate::api::plugin::traits::Plugin;
use crate::api::plugin::types::{PluginAdapter, PluginType};
use crate::api::plugin::wasm_runtime::{HostPluginStore, SharedWasmEngine};
use crate::utils::http;
use std::any::Any;
use std::collections::HashMap;

use bindgen::{exports_data_source, exports_discovery};

/// ContentResolverHostImpl provides HTTP and utility host functions for content resolver plugins
#[flutter_rust_bridge::frb(opaque)]
pub struct ContentResolverHostImpl {
    _plugin_id: String,
    storage: HashMap<String, String>,
}

impl ContentResolverHostImpl {
    pub fn new(plugin_id: String) -> Self {
        Self {
            _plugin_id: plugin_id,
            storage: HashMap::new(),
        }
    }
}

impl Default for ContentResolverHostImpl {
    fn default() -> Self {
        Self::new("unknown".to_string())
    }
}

impl bindgen::UtilsHost for ContentResolverHostImpl {
    fn http_request(
        &mut self,
        url: String,
        options: bindgen::RequestOptions,
    ) -> Result<bindgen::HttpResponse, String> {
        let method = match options.method {
            bindgen::HttpMethod::Get => reqwest::Method::GET,
            bindgen::HttpMethod::Post => reqwest::Method::POST,
            bindgen::HttpMethod::Put => reqwest::Method::PUT,
            bindgen::HttpMethod::Delete => reqwest::Method::DELETE,
            bindgen::HttpMethod::Head => reqwest::Method::HEAD,
            bindgen::HttpMethod::Patch => reqwest::Method::PATCH,
            bindgen::HttpMethod::Options => reqwest::Method::OPTIONS,
        };
        let response = http::send_blocking(http::Request {
            method,
            url,
            headers: options.headers.unwrap_or_default(),
            body: options.body,
            timeout_seconds: options.timeout_seconds,
        })?;
        Ok(bindgen::HttpResponse {
            status: response.status,
            headers: response.headers,
            body: response.body,
        })
    }

    fn random_number(&mut self) -> u64 {
        use rand::Rng;
        rand::thread_rng().gen()
    }

    fn current_unix_timestamp(&mut self) -> u64 {
        use std::time::{SystemTime, UNIX_EPOCH};
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
    }

    fn storage_get(&mut self, key: String) -> Option<String> {
        self.storage.get(&key).cloned()
    }

    fn storage_set(&mut self, key: String, value: String) -> bool {
        self.storage.insert(key, value);
        true
    }
}

/// Internal state for ContentResolver plugin
pub struct ContentResolverWasmState {
    instance: waclay::Instance,
    store: HostPluginStore<ContentResolverHostImpl>,
}

pub struct ContentResolverPluginAdapter {
    name: String,
    state: ContentResolverWasmState,
}

impl ContentResolverPluginAdapter {
    pub async fn load(
        name: String,
        wasm_path: String,
        engine: SharedWasmEngine,
    ) -> PluginResult<Self> {
        let mut store = HostPluginStore::new(&engine, ContentResolverHostImpl::new(name.clone()));

        let instance = get_instance_with_host(&mut store, engine, &wasm_path, |linker, store| {
            bindgen::imports::register_utils_host::<ContentResolverHostImpl, _>(linker, store)
                .map_err(|e| format!("Failed to register host functions: {:?}", e))?;
            Ok(())
        })
        .await
        .map_err(|e| {
            PluginError::WasmExecutionError(format!(
                "Failed to load WASM for plugin '{}': {}",
                &name, e
            ))
        })?;

        Ok(Self {
            name,
            state: ContentResolverWasmState { instance, store },
        })
    }
}

impl Plugin for ContentResolverPluginAdapter {
    fn get_name(&self) -> &str {
        &self.name
    }

    fn get_plugin_type(&self) -> PluginType {
        PluginType::ContentResolver
    }

    fn handle_request(
        &mut self,
        request: crate::api::plugin::commands::PluginRequest,
    ) -> PluginResult<PluginResponse> {
        use crate::api::plugin::commands::PluginRequest;
        if let PluginRequest::ContentResolver(command) = request {
            let state = &mut self.state;
            let plugin_id = &self.name;

            let response = match command {
                ContentResolverCommand::GetTrackDetails { id } => {
                    let func = exports_data_source::get_get_track_details(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, id)
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::TrackDetails(to_audio_track(result)))
                }
                ContentResolverCommand::GetHomeSections => {
                    let func =
                        exports_discovery::get_get_home_sections(&state.instance, &mut state.store)
                            .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, ())
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::HomeSections(
                        result.into_iter().map(to_audio_section).collect(),
                    ))
                }
                ContentResolverCommand::LoadMore { id, more_link } => {
                    let func = exports_discovery::get_load_more(&state.instance, &mut state.store)
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, (id, more_link))
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::LoadMoreItems(
                        result.into_iter().map(to_audio_media_item).collect(),
                    ))
                }
                ContentResolverCommand::GetAlbumDetails { id } => {
                    let func = exports_data_source::get_get_album_details(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, id)
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::AlbumDetails(to_audio_album_details(
                        result,
                    )))
                }
                ContentResolverCommand::GetArtistDetails { id } => {
                    let func = exports_data_source::get_get_artist_details(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, id)
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::ArtistDetails(to_audio_artist_details(
                        result,
                    )))
                }
                ContentResolverCommand::GetPlaylistDetails { id } => {
                    let func = exports_data_source::get_get_playlist_details(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, id)
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::PlaylistDetails(
                        to_audio_playlist_details(result),
                    ))
                }
                ContentResolverCommand::GetStreams { id } => {
                    let func =
                        exports_data_source::get_get_streams(&state.instance, &mut state.store)
                            .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, id)
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::Streams(
                        result.into_iter().map(to_audio_stream_source).collect(),
                    ))
                }
                ContentResolverCommand::Search {
                    query,
                    filter,
                    page_token,
                } => {
                    let func = exports_data_source::get_search(&state.instance, &mut state.store)
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let filter_enum = to_bindgen_search_filter(filter);
                    let result = func
                        .call(&mut state.store, (query, filter_enum, page_token))
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::Search(to_paged_audio_media_items(
                        result,
                    )))
                }
                ContentResolverCommand::MoreAlbumTracks { id, page_token } => {
                    let func = exports_data_source::get_more_album_tracks(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, (id, page_token))
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::MoreTracks(to_paged_audio_tracks(result)))
                }
                ContentResolverCommand::MoreArtistAlbums { id, page_token } => {
                    let func = exports_data_source::get_more_artist_albums(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, (id, page_token))
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::MoreAlbums(to_paged_audio_albums(result)))
                }
                ContentResolverCommand::MorePlaylistTracks { id, page_token } => {
                    let func = exports_data_source::get_more_playlist_tracks(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, (id, page_token))
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::MoreTracks(to_paged_audio_tracks(result)))
                }
                ContentResolverCommand::GetRadioTracks { id, page_token } => {
                    let func = exports_data_source::get_get_radio_tracks(
                        &state.instance,
                        &mut state.store,
                    )
                    .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?;
                    let result = func
                        .call(&mut state.store, (id, page_token))
                        .map_err(|e| PluginError::WasmExecutionError(e.to_string()))?
                        .map_err(|e| PluginError::WasmExecutionError(e))?;
                    Ok(PluginResponse::MoreTracks(to_paged_audio_tracks(result)))
                }
                ContentResolverCommand::GetSegmentsForTrack { id: _ } => {
                    // Segments are not part of the content resolver WIT interface.
                    // Return empty list; segment data is expected from dedicated sources.
                    Ok(PluginResponse::Segments(vec![]))
                }
            }?;

            // Stamp all entity IDs with "pluginId::" prefix before crossing the FRB boundary.
            // Streams carry playback URLs, not entity IDs — they are not stamped.
            Ok(stamp_response(plugin_id, response))
        } else {
            Err(PluginError::InvalidConfiguration(format!(
                "Invalid request type for ContentResolver: {:?}",
                request
            )))
        }
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    fn as_any_mut(&mut self) -> &mut dyn Any {
        self
    }
}

impl PluginAdapter for ContentResolverPluginAdapter {
    fn plugin_type() -> PluginType {
        PluginType::ContentResolver
    }

    async fn create(
        name: String,
        wasm_path: String,
        engine: SharedWasmEngine,
    ) -> PluginResult<Box<dyn Plugin>> {
        Ok(Box::new(Self::load(name, wasm_path, engine).await?))
    }
}

// Converters

fn to_audio_artwork(a: bindgen::Artwork) -> Artwork {
    Artwork {
        url: a.url,
        url_low: a.url_low,
        url_high: a.url_high,
        layout: match a.layout {
            bindgen::ImageLayout::Square => ImageLayout::Square,
            bindgen::ImageLayout::Portrait => ImageLayout::Portrait,
            bindgen::ImageLayout::Landscape => ImageLayout::Landscape,
            bindgen::ImageLayout::Banner => ImageLayout::Banner,
            bindgen::ImageLayout::Circular => ImageLayout::Circular,
        },
    }
}

fn to_audio_artist(a: bindgen::ArtistSummary) -> ArtistSummary {
    ArtistSummary {
        id: a.id,
        name: a.name,
        thumbnail: a.thumbnail.map(to_audio_artwork),
        subtitle: a.subtitle,
        url: a.url,
    }
}

fn to_audio_lyrics(l: bindgen::Lyrics) -> Lyrics {
    Lyrics {
        plain: l.plain,
        synced: l.synced,
        copyright: l.copyright,
    }
}

fn to_audio_quality(q: bindgen::Quality) -> Quality {
    match q {
        bindgen::Quality::Low => Quality::Low,
        bindgen::Quality::Medium => Quality::Medium,
        bindgen::Quality::High => Quality::High,
        bindgen::Quality::Lossless => Quality::Lossless,
    }
}

fn to_audio_stream_source(s: bindgen::StreamSource) -> StreamSource {
    StreamSource {
        url: s.url,
        quality: to_audio_quality(s.quality),
        format: s.format,
        headers: s.headers,
        expires_at: s.expires_at,
    }
}

fn to_audio_album(a: bindgen::AlbumSummary) -> AlbumSummary {
    AlbumSummary {
        id: a.id,
        title: a.title,
        artists: a.artists.into_iter().map(to_audio_artist).collect(),
        thumbnail: a.thumbnail.map(to_audio_artwork),
        subtitle: a.subtitle,
        year: a.year,
        url: a.url,
    }
}

fn to_audio_track(t: bindgen::Track) -> Track {
    Track {
        id: t.id,
        title: t.title,
        artists: t.artists.into_iter().map(to_audio_artist).collect(),
        album: t.album.map(to_audio_album),
        duration_ms: t.duration_ms,
        thumbnail: to_audio_artwork(t.thumbnail),
        url: t.url,
        is_explicit: t.is_explicit,
        lyrics: t.lyrics.map(to_audio_lyrics),
    }
}

fn to_audio_playlist(p: bindgen::PlaylistSummary) -> PlaylistSummary {
    PlaylistSummary {
        id: p.id,
        title: p.title,
        owner: p.owner,
        thumbnail: to_audio_artwork(p.thumbnail),
        url: p.url,
    }
}

fn to_audio_media_item(m: bindgen::MediaItem) -> MediaItem {
    match m {
        bindgen::MediaItem::Track(t) => MediaItem::Track(to_audio_track(t)),
        bindgen::MediaItem::Album(a) => MediaItem::Album(to_audio_album(a)),
        bindgen::MediaItem::Artist(a) => MediaItem::Artist(to_audio_artist(a)),
        bindgen::MediaItem::Playlist(p) => MediaItem::Playlist(to_audio_playlist(p)),
    }
}

fn to_audio_section(s: bindgen::Section) -> Section {
    Section {
        id: s.id,
        title: s.title,
        subtitle: s.subtitle,
        card_type: match s.card_type {
            bindgen::SectionType::Carousel => CardType::Carousel,
            bindgen::SectionType::Grid => CardType::Grid,
            bindgen::SectionType::Vlist => CardType::Vlist,
        },
        items: s.items.into_iter().map(to_audio_media_item).collect(),
        more_link: s.more_link,
    }
}

fn to_paged_audio_media_items(p: bindgen::PagedMediaItems) -> PagedMediaItems {
    PagedMediaItems {
        items: p.items.into_iter().map(to_audio_media_item).collect(),
        next_page_token: p.next_page_token,
    }
}

fn to_paged_audio_albums(p: bindgen::PagedAlbums) -> PagedAlbums {
    PagedAlbums {
        items: p.items.into_iter().map(to_audio_album).collect(),
        next_page_token: p.next_page_token,
    }
}

fn to_paged_audio_tracks(p: bindgen::PagedTracks) -> PagedTracks {
    PagedTracks {
        items: p.items.into_iter().map(to_audio_track).collect(),
        next_page_token: p.next_page_token,
    }
}

fn to_audio_album_details(d: bindgen::AlbumDetails) -> AlbumDetails {
    AlbumDetails {
        summary: to_audio_album(d.summary),
        tracks: to_paged_audio_tracks(d.tracks),
        description: d.description,
    }
}

fn to_audio_artist_details(d: bindgen::ArtistDetails) -> ArtistDetails {
    ArtistDetails {
        summary: to_audio_artist(d.summary),
        top_tracks: d.top_tracks.into_iter().map(to_audio_track).collect(),
        albums: to_paged_audio_albums(d.albums),
        related_artists: d.related_artists.into_iter().map(to_audio_artist).collect(),
        description: d.description,
    }
}

fn to_audio_playlist_details(d: bindgen::PlaylistDetails) -> PlaylistDetails {
    PlaylistDetails {
        summary: to_audio_playlist(d.summary),
        tracks: to_paged_audio_tracks(d.tracks),
        description: d.description,
    }
}

fn to_bindgen_search_filter(filter: ContentSearchFilter) -> bindgen::SearchFilter {
    match filter {
        ContentSearchFilter::All => bindgen::SearchFilter::All,
        ContentSearchFilter::Track => bindgen::SearchFilter::Track,
        ContentSearchFilter::Album => bindgen::SearchFilter::Album,
        ContentSearchFilter::Artist => bindgen::SearchFilter::Artist,
        ContentSearchFilter::Playlist => bindgen::SearchFilter::Playlist,
    }
}

// ── ID Stamping ──────────────────────────────────────────────────────────────
// Stamps all entity IDs in a PluginResponse with "pluginId::localId" format.
// Already-stamped IDs (containing "::") are left untouched.
// Streams carry playback URLs and synthetic IDs — not stamped.

const STAMP_SEP: &str = "::";

fn stamp_id(plugin_id: &str, id: &str) -> String {
    if id.contains(STAMP_SEP) {
        id.to_string()
    } else {
        format!("{}{}{}", plugin_id, STAMP_SEP, id)
    }
}

fn stamp_track(pid: &str, mut t: Track) -> Track {
    t.id = stamp_id(pid, &t.id);
    t.artists = t.artists.into_iter().map(|a| stamp_artist(pid, a)).collect();
    t.album = t.album.map(|a| stamp_album(pid, a));
    t
}

fn stamp_artist(pid: &str, mut a: ArtistSummary) -> ArtistSummary {
    a.id = stamp_id(pid, &a.id);
    a
}

fn stamp_album(pid: &str, mut a: AlbumSummary) -> AlbumSummary {
    a.id = stamp_id(pid, &a.id);
    a.artists = a.artists.into_iter().map(|ar| stamp_artist(pid, ar)).collect();
    a
}

fn stamp_playlist(pid: &str, mut p: PlaylistSummary) -> PlaylistSummary {
    p.id = stamp_id(pid, &p.id);
    p
}

fn stamp_media_item(pid: &str, item: MediaItem) -> MediaItem {
    match item {
        MediaItem::Track(t) => MediaItem::Track(stamp_track(pid, t)),
        MediaItem::Album(a) => MediaItem::Album(stamp_album(pid, a)),
        MediaItem::Artist(a) => MediaItem::Artist(stamp_artist(pid, a)),
        MediaItem::Playlist(p) => MediaItem::Playlist(stamp_playlist(pid, p)),
    }
}

fn stamp_section(pid: &str, mut s: Section) -> Section {
    s.items = s.items.into_iter().map(|i| stamp_media_item(pid, i)).collect();
    s
}

fn stamp_chart_summary(pid: &str, mut c: ChartSummary) -> ChartSummary {
    c.id = stamp_id(pid, &c.id);
    c
}

fn stamp_chart_item(pid: &str, mut c: ChartItem) -> ChartItem {
    c.item = stamp_media_item(pid, c.item);
    c
}

fn stamp_paged_media_items(pid: &str, mut p: PagedMediaItems) -> PagedMediaItems {
    p.items = p.items.into_iter().map(|i| stamp_media_item(pid, i)).collect();
    p
}

fn stamp_paged_tracks(pid: &str, mut p: PagedTracks) -> PagedTracks {
    p.items = p.items.into_iter().map(|t| stamp_track(pid, t)).collect();
    p
}

fn stamp_paged_albums(pid: &str, mut p: PagedAlbums) -> PagedAlbums {
    p.items = p.items.into_iter().map(|a| stamp_album(pid, a)).collect();
    p
}

fn stamp_response(plugin_id: &str, response: PluginResponse) -> PluginResponse {
    match response {
        PluginResponse::TrackDetails(t) => PluginResponse::TrackDetails(stamp_track(plugin_id, t)),
        PluginResponse::Search(p) => PluginResponse::Search(stamp_paged_media_items(plugin_id, p)),
        PluginResponse::AlbumDetails(d) => PluginResponse::AlbumDetails(AlbumDetails {
            summary: stamp_album(plugin_id, d.summary),
            tracks: stamp_paged_tracks(plugin_id, d.tracks),
            description: d.description,
        }),
        PluginResponse::ArtistDetails(d) => PluginResponse::ArtistDetails(ArtistDetails {
            summary: stamp_artist(plugin_id, d.summary),
            top_tracks: d.top_tracks.into_iter().map(|t| stamp_track(plugin_id, t)).collect(),
            albums: stamp_paged_albums(plugin_id, d.albums),
            related_artists: d.related_artists.into_iter().map(|a| stamp_artist(plugin_id, a)).collect(),
            description: d.description,
        }),
        PluginResponse::PlaylistDetails(d) => PluginResponse::PlaylistDetails(PlaylistDetails {
            summary: stamp_playlist(plugin_id, d.summary),
            tracks: stamp_paged_tracks(plugin_id, d.tracks),
            description: d.description,
        }),
        // Streams carry playback URLs, not routable entity IDs — pass through.
        PluginResponse::Streams(streams) => PluginResponse::Streams(streams),
        PluginResponse::MoreTracks(p) => PluginResponse::MoreTracks(stamp_paged_tracks(plugin_id, p)),
        PluginResponse::MoreAlbums(p) => PluginResponse::MoreAlbums(stamp_paged_albums(plugin_id, p)),
        PluginResponse::HomeSections(sections) => PluginResponse::HomeSections(
            sections.into_iter().map(|s| stamp_section(plugin_id, s)).collect(),
        ),
        PluginResponse::LoadMoreItems(items) => PluginResponse::LoadMoreItems(
            items.into_iter().map(|i| stamp_media_item(plugin_id, i)).collect(),
        ),
        PluginResponse::Charts(charts) => PluginResponse::Charts(
            charts.into_iter().map(|c| stamp_chart_summary(plugin_id, c)).collect(),
        ),
        PluginResponse::ChartDetails(items) => PluginResponse::ChartDetails(
            items.into_iter().map(|c| stamp_chart_item(plugin_id, c)).collect(),
        ),
        PluginResponse::Segments(s) => PluginResponse::Segments(s),
        PluginResponse::LyricsResult(r) => PluginResponse::LyricsResult(r),
        PluginResponse::LyricsSearchResults(r) => PluginResponse::LyricsSearchResults(r),
        PluginResponse::LyricsById(l, m) => PluginResponse::LyricsById(l, m),
        PluginResponse::Suggestions(s) => PluginResponse::Suggestions(s),
        PluginResponse::CanHandle(b) => PluginResponse::CanHandle(b),
        PluginResponse::CollectionInfo(c) => PluginResponse::CollectionInfo(c),
        PluginResponse::ImportTracks(t) => PluginResponse::ImportTracks(t),
        PluginResponse::Ack => PluginResponse::Ack,
    }
}
